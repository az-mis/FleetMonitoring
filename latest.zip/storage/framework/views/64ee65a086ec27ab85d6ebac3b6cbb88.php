<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['role']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['role']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $color = $role->badgeColor();
    $classes = match ($color) {
        'purple' => 'bg-purple-50 text-purple-700 ring-purple-600/20',
        'blue' => 'bg-blue-50 text-blue-700 ring-blue-600/20',
        default => 'bg-gray-50 text-gray-700 ring-gray-600/20',
    };
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset {$classes}"])); ?>>
    <?php echo e($role->label()); ?>

</span>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Admin\Providers/../Views/components/role-badge.blade.php ENDPATH**/ ?>