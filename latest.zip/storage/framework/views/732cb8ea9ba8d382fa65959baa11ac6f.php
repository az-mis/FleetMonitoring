<?php if($vehicles->isEmpty()): ?>
    <div class="rounded-xl border border-dashed border-gray-300 bg-white px-6 py-14 text-center">
        <p class="text-sm font-medium text-gray-900">No vehicles found</p>
        <p class="mt-1 text-sm text-gray-500">
            <?php if(request('search')): ?>
                No results match "<?php echo e(request('search')); ?>".
            <?php else: ?>
                Get started by registering your first vehicle.
            <?php endif; ?>
        </p>
    </div>
<?php else: ?>
    
    <div id="vehicle-view-list" class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Vehicle</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Plate Number</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Type</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Color</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Odometer</th>
                        <th class="whitespace-nowrap px-5 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-500">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50/60">
                            <td class="whitespace-nowrap px-5 py-3.5">
                                <div class="flex items-center gap-3">
                                    <?php if($vehicle->photo_url): ?>
                                        <img src="<?php echo e($vehicle->photo_url); ?>" alt="<?php echo e($vehicle->plate_number); ?>" class="h-8 w-8 shrink-0 rounded-lg object-cover">
                                    <?php else: ?>
                                        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                <path d="M3 13h2l2-6h10l2 6h2"/>
                                                <path d="M5 13v5a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h8v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-5"/>
                                                <circle cx="7.5" cy="16.5" r="1.5"/>
                                                <circle cx="16.5" cy="16.5" r="1.5"/>
                                            </svg>
                                        </div>
                                    <?php endif; ?>
                                    <div class="min-w-0">
                                        <p class="truncate text-sm font-medium text-gray-900"><?php echo e($vehicle->brand); ?> <?php echo e($vehicle->model); ?></p>
                                        <p class="truncate text-xs text-gray-500"><?php echo e($vehicle->year); ?> &middot; <?php echo e($vehicle->color); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="whitespace-nowrap px-5 py-3.5">
                                <span class="inline-flex items-center rounded-full bg-gray-50 px-2.5 py-1 text-xs font-medium text-gray-700 ring-1 ring-inset ring-gray-600/20">
                                    <?php echo e($vehicle->plate_number); ?>

                                </span>
                            </td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-sm text-gray-600"><?php echo e($vehicle->vehicle_type ? ucfirst($vehicle->vehicle_type) : '—'); ?></td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-sm text-gray-600"><?php echo e($vehicle->color); ?></td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-sm text-gray-500"><?php echo e(number_format($vehicle->odometer)); ?> km</td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-right">
                                <?php if (isset($component)) { $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'vehicle::components.row-actions','data' => ['vehicle' => $vehicle]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vehicle::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['vehicle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicle)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $attributes = $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $component = $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div id="vehicle-view-grid" class="hidden grid grid-cols-1 gap-4 xs:grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                <?php if($vehicle->photo_url): ?>
                    <img src="<?php echo e($vehicle->photo_url); ?>" alt="<?php echo e($vehicle->plate_number); ?>" class="h-44 w-full object-cover">
                <?php else: ?>
                    <div class="flex h-44 w-full items-center justify-center bg-emerald-50 text-emerald-600">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 13h2l2-6h10l2 6h2"/>
                            <path d="M5 13v5a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h8v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-5"/>
                            <circle cx="7.5" cy="16.5" r="1.5"/>
                            <circle cx="16.5" cy="16.5" r="1.5"/>
                        </svg>
                    </div>
                <?php endif; ?>

                <div class="p-4">
                    <p class="truncate text-base font-semibold text-gray-900"><?php echo e($vehicle->plate_number); ?></p>
                    <p class="mt-0.5 truncate text-sm text-gray-500">
                        <?php echo e($vehicle->brand); ?> <?php echo e($vehicle->model); ?> &middot; <?php echo e($vehicle->year); ?> &middot; <?php echo e($vehicle->color); ?>

                    </p>

                    <div class="mt-3 flex flex-wrap items-center gap-2">
                        <?php if($vehicle->vehicle_type): ?>
                            <span class="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-700">
                                <?php echo e(ucfirst($vehicle->vehicle_type)); ?>

                            </span>
                        <?php endif; ?>
                        <?php if($vehicle->fuel_type): ?>
                            <span class="inline-flex items-center rounded-full bg-purple-50 px-2.5 py-1 text-xs font-medium text-purple-700">
                                <?php echo e(ucfirst($vehicle->fuel_type)); ?>

                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4 flex items-center justify-between border-t border-gray-100 pt-3">
                        <span class="text-xs text-gray-400"><?php echo e(number_format($vehicle->odometer)); ?> km</span>
                        <?php if (isset($component)) { $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'vehicle::components.row-actions','data' => ['vehicle' => $vehicle]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vehicle::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['vehicle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicle)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $attributes = $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $component = $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6 overflow-x-auto">
        <?php echo e($vehicles->links()); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Vehicle\Providers/../Views/partials/vehicle-results.blade.php ENDPATH**/ ?>