<?php if($admins->isEmpty()): ?>
    <div class="rounded-xl border border-dashed border-gray-300 bg-white px-6 py-14 text-center">
        <p class="text-sm font-medium text-gray-900">No admins found</p>
        <p class="mt-1 text-sm text-gray-500">
            <?php if(request('search')): ?>
                No results match "<?php echo e(request('search')); ?>".
            <?php else: ?>
                Get started by adding your first admin.
            <?php endif; ?>
        </p>
    </div>
<?php else: ?>
    
    <div id="admin-view-list" class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Name</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Email</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Role</th>
                        <th class="whitespace-nowrap px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Joined</th>
                        <th class="whitespace-nowrap px-5 py-3 text-right text-xs font-semibold uppercase tracking-wide text-gray-500">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50/60">
                            <td class="whitespace-nowrap px-5 py-3.5">
                                <div class="flex items-center gap-3">
                                    <?php if($admin->avatar_url): ?>
                                        <img src="<?php echo e($admin->avatar_url); ?>" alt="<?php echo e($admin->name); ?>" class="h-8 w-8 shrink-0 rounded-full object-cover">
                                    <?php else: ?>
                                        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-xs font-semibold text-emerald-700">
                                            <?php echo e(Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($admin->name, 0, 1))); ?>

                                        </div>
                                    <?php endif; ?>
                                    <span class="text-sm font-medium text-gray-900"><?php echo e($admin->name); ?></span>
                                </div>
                            </td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-sm text-gray-600"><?php echo e($admin->email); ?></td>
                            <td class="whitespace-nowrap px-5 py-3.5">
                                <?php if (isset($component)) { $__componentOriginalb954e539ebbc4c303f4792091c53fd5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.role-badge','data' => ['role' => $admin->role]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::role-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin->role)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $attributes = $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $component = $__componentOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
                            </td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-sm text-gray-500"><?php echo e($admin->created_at->format('M d, Y')); ?></td>
                            <td class="whitespace-nowrap px-5 py-3.5 text-right">
                                <?php if (isset($component)) { $__componentOriginala24a7c221641f08078ec61e81b617907 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala24a7c221641f08078ec61e81b617907 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.row-actions','data' => ['admin' => $admin]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala24a7c221641f08078ec61e81b617907)): ?>
<?php $attributes = $__attributesOriginala24a7c221641f08078ec61e81b617907; ?>
<?php unset($__attributesOriginala24a7c221641f08078ec61e81b617907); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala24a7c221641f08078ec61e81b617907)): ?>
<?php $component = $__componentOriginala24a7c221641f08078ec61e81b617907; ?>
<?php unset($__componentOriginala24a7c221641f08078ec61e81b617907); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div id="admin-view-grid" class="hidden grid grid-cols-1 gap-4 xs:grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm sm:p-5">
                <div class="flex items-start justify-between gap-2">
                    <div class="flex min-w-0 items-center gap-3">
                        <?php if($admin->avatar_url): ?>
                            <img src="<?php echo e($admin->avatar_url); ?>" alt="<?php echo e($admin->name); ?>" class="h-10 w-10 shrink-0 rounded-full object-cover">
                        <?php else: ?>
                            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-sm font-semibold text-emerald-700">
                                <?php echo e(Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($admin->name, 0, 1))); ?>

                            </div>
                        <?php endif; ?>
                        <div class="min-w-0">
                            <p class="truncate text-sm font-semibold text-gray-900"><?php echo e($admin->name); ?></p>
                            <p class="truncate text-xs text-gray-500"><?php echo e($admin->email); ?></p>
                        </div>
                    </div>
                </div>

                <div class="mt-4 flex flex-wrap items-center justify-between gap-2">
                    <?php if (isset($component)) { $__componentOriginalb954e539ebbc4c303f4792091c53fd5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.role-badge','data' => ['role' => $admin->role]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::role-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin->role)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $attributes = $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $component = $__componentOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
                    <span class="text-xs text-gray-400"><?php echo e($admin->created_at->format('M d, Y')); ?></span>
                </div>

                <div class="mt-4 flex items-center justify-end gap-1 border-t border-gray-100 pt-3">
                    <?php if (isset($component)) { $__componentOriginala24a7c221641f08078ec61e81b617907 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala24a7c221641f08078ec61e81b617907 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.row-actions','data' => ['admin' => $admin]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala24a7c221641f08078ec61e81b617907)): ?>
<?php $attributes = $__attributesOriginala24a7c221641f08078ec61e81b617907; ?>
<?php unset($__attributesOriginala24a7c221641f08078ec61e81b617907); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala24a7c221641f08078ec61e81b617907)): ?>
<?php $component = $__componentOriginala24a7c221641f08078ec61e81b617907; ?>
<?php unset($__componentOriginala24a7c221641f08078ec61e81b617907); ?>
<?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6 overflow-x-auto">
        <?php echo e($admins->links()); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Admin\Providers/../Views/partials/admin-results.blade.php ENDPATH**/ ?>