@extends('layouts.app')

@section('title', 'Vehicles')
@section('page-title', 'Vehicles')

@section('content')
    @php
        $locationOptions = [
            'Oriental Mindoro',
            'Occidental Mindoro',
            'Marinduque',
            'Palawan',
            'Romblon',
            'Quezon City Satellite Office',
        ];
        // The controller already resolves the effective location: the ?location= filter for
        // super admins, the admin's own assigned location for everyone else. Only fall back
        // to the query string if it wasn't passed in.
        $selectedLocation = $selectedLocation ?? request('location');
        $locationButtonLabel = $selectedLocation ?: 'All Locations';
    @endphp

    {{-- Page header --}}
    <div class="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
            <h1 class="text-2xl font-extrabold tracking-tight text-slate-900">Vehicles</h1>
            <p class="text-sm text-slate-500">Manage your fleet vehicles</p>
        </div>

        <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
            <form method="GET" action="{{ route('vehicles.index') }}" id="vehicle-search-form" class="flex w-full min-w-0 items-center gap-2 sm:w-72 xl:w-96" onsubmit="return false;">
                <div class="relative w-full">
                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-600/70" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="7"/>
                        <path d="m21 21-4.3-4.3"/>
                    </svg>
                    <input
                        type="text"
                        name="search"
                        id="vehicle-search-input"
                        value="{{ request('search') }}"
                        autocomplete="off"
                        placeholder="Search by plate number, brand, model, or VIN..."
                        oninput="onVehicleSearchInput()"
                        class="w-full rounded-full border border-slate-200 bg-white py-2.5 pl-10 pr-8 text-xs text-slate-800 placeholder-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                    <svg id="vehicle-search-spinner" xmlns="http://www.w3.org/2000/svg" class="hidden absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                    </svg>
                </div>

                <a href="{{ route('vehicles.index') }}" id="vehicle-search-clear" onclick="return clearVehicleSearch(event)" class="shrink-0 text-xs font-semibold text-slate-500 hover:text-slate-700 {{ request('search') ? '' : 'hidden' }}">Clear</a>
            </form>

            <div class="flex flex-wrap items-center gap-2">
                {{-- Location filter (moved up from the chips row) --}}
                @if ($isSuperAdmin)
                    <div class="relative">
                        <button
                            type="button"
                            onclick="toggleVehicleLocationMenu()"
                            class="inline-flex h-10 items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 cursor-pointer"
                        >
                            <span class="flex items-center gap-1.5 truncate">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                                    <circle cx="12" cy="10" r="3"/>
                                </svg>
                                <span class="max-w-[9rem] truncate">{{ $locationButtonLabel }}</span>
                            </span>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-slate-400 shrink-0 transition" id="vehicle-location-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="m6 9 6 6 6-6"/>
                            </svg>
                        </button>

                        <div id="vehicle-location-menu" class="absolute left-0 z-20 mt-2 hidden w-64 sm:left-auto sm:right-0 overflow-hidden rounded-xl bg-white p-1.5 shadow-xl ring-1 ring-black/5">
                            <a href="{{ route('vehicles.index', array_filter(['search' => request('search'), 'per_page' => request('per_page')])) }}" class="flex items-center justify-between rounded-lg px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-gray-50 {{ !$selectedLocation ? 'bg-emerald-50 text-emerald-800' : '' }}">
                                <span>All Locations</span>
                                @if(!$selectedLocation)
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                                @endif
                            </a>
                            @foreach($locationOptions as $opt)
                                <a href="{{ route('vehicles.index', array_filter(['search' => request('search'), 'per_page' => request('per_page'), 'location' => $opt])) }}" class="flex items-center justify-between rounded-lg px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-gray-50 {{ $selectedLocation === $opt ? 'bg-emerald-50 text-emerald-800' : '' }}">
                                    <span>{{ $opt }}</span>
                                    @if($selectedLocation === $opt)
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                                    @endif
                                </a>
                            @endforeach
                        </div>
                    </div>
                @else
                    <div class="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
                            <circle cx="12" cy="10" r="3"/>
                        </svg>
                        <span class="max-w-[9rem] truncate">{{ $selectedLocation ?: 'All Locations' }}</span>
                    </div>
                @endif

                {{-- View toggle buttons (segmented switch) --}}
                <div class="flex h-10 shrink-0 items-center rounded-xl border border-slate-200 bg-white p-1">
                    <button
                        type="button"
                        id="vehicle-view-toggle-list"
                        onclick="setVehicleView('list')"
                        class="vehicle-view-toggle-btn flex h-full w-8 items-center justify-center rounded-lg transition text-slate-400 hover:text-slate-600"
                        title="List View"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="8" y1="6" x2="21" y2="6"/>
                            <line x1="8" y1="12" x2="21" y2="12"/>
                            <line x1="8" y1="18" x2="21" y2="18"/>
                            <line x1="3" y1="6" x2="3.01" y2="6"/>
                            <line x1="3" y1="12" x2="3.01" y2="12"/>
                            <line x1="3" y1="18" x2="3.01" y2="18"/>
                        </svg>
                    </button>
                    <button
                        type="button"
                        id="vehicle-view-toggle-grid"
                        onclick="setVehicleView('grid')"
                        class="vehicle-view-toggle-btn flex h-full w-8 items-center justify-center rounded-lg transition text-slate-400 hover:text-slate-600"
                        title="Grid View"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="3" width="7" height="7" rx="1"/>
                            <rect x="14" y="3" width="7" height="7" rx="1"/>
                            <rect x="3" y="14" width="7" height="7" rx="1"/>
                            <rect x="14" y="14" width="7" height="7" rx="1"/>
                        </svg>
                    </button>
                </div>

                <button
                    type="button"
                    onclick="openRegisterVehicleModal()"
                    class="inline-flex h-10 shrink-0 items-center justify-center gap-1.5 rounded-xl bg-[#005a36] px-4 text-xs font-extrabold text-white shadow-sm hover:bg-[#00432a] transition cursor-pointer"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 5v14M5 12h14"/>

                    </svg>
                    <span>Register Vehicle</span>
                </button>
            </div>
        </div>
    </div>

    {{-- Category filter chips (one per row in the vehicle_types table) --}}
    <div class="mb-4 flex flex-wrap items-center gap-2">
        <button type="button" onclick="setVehicleCategoryFilter('all')" data-category-filter="all" class="vehicle-category-chip active">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>
            </svg>
            <span>All Vehicles ({{ $totalVehicleCount }})</span>
        </button>

        @foreach ($vehicleTypes as $vehicleType)
            <button type="button" onclick="setVehicleCategoryFilter('{{ $vehicleType->slug }}')" data-category-filter="{{ $vehicleType->slug }}" class="vehicle-category-chip">
                @include('vehicle::partials.vehicle-type-icon', ['iconOverride' => $vehicleType->icon, 'class' => 'h-5 w-5 shrink-0', 'stroke' => '1.75'])
                <span>{{ $vehicleType->chipLabel() }} ({{ $typeCounts[$vehicleType->slug] ?? 0 }})</span>
            </button>
        @endforeach

        <button type="button" onclick="openAddVehicleTypeModal()" class="vehicle-category-chip vehicle-category-chip-add">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 5v14M5 12h14"/>
            </svg>
            <span>Add Vehicle Type</span>
        </button>
    </div>

    <div id="vehicle-results">
        @include('vehicle::partials.vehicle-results', ['vehicles' => $vehicles])
    </div>

    {{-- Register Vehicle modal --}}
    @php
        $rvOld = fn (string $key, $default = '') => old('_vehicle_form') === 'create' ? old($key, $default) : $default;

        $rvBrands = ['Toyota', 'Mitsubishi', 'Nissan', 'Isuzu', 'Ford', 'Honda', 'Hyundai', 'Suzuki', 'Kia', 'Mazda', 'Chevrolet', 'Subaru', 'BMW', 'Mercedes-Benz', 'Foton', 'Yamaha', 'Kawasaki'];
        $rvTypes  = $vehicleTypes->pluck('name')->all();
        $rvFuels  = ['Gasoline', 'Diesel', 'Hybrid', 'Electric', 'LPG'];

        $rvBrandValue   = (string) $rvOld('brand');
        $rvBrandIsOther = $rvBrandValue !== '' && ! in_array($rvBrandValue, $rvBrands, true);
        $rvTypeValue    = (string) $rvOld('vehicle_type');
        $rvFuelValue    = (string) $rvOld('fuel_type');

        $rvLabel     = 'mb-1.5 block text-[13px] font-semibold text-slate-700';
        $rvInputBase = 'h-11 w-full rounded-lg border px-3 text-sm placeholder-slate-400 transition focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600';
        $rvInput     = $rvInputBase . ' bg-white text-slate-800';
        $rvSelect    = $rvInput . ' cursor-pointer appearance-none pr-9 invalid:text-slate-400';
        $rvNoSpin    = '[appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none';
        $rvBorder    = fn (string $field) => $errors->has($field) ? 'border-red-400' : 'border-slate-200';
    @endphp

    <style>
        #register-vehicle-modal option, #edit-vehicle-modal option { color: #1e293b; }
    </style>

    <div id="register-vehicle-modal" class="fixed inset-0 z-50 hidden items-stretch justify-center bg-black/50 backdrop-blur-sm sm:items-center sm:p-6">
        <div class="flex h-full w-full flex-col overflow-hidden bg-white shadow-2xl sm:h-auto sm:max-h-[92vh] sm:max-w-3xl sm:rounded-2xl">

            {{-- Header --}}
            <div class="flex shrink-0 items-center justify-between bg-[#005a36] px-5 py-4 text-white sm:px-6">
                <div class="flex min-w-0 items-center gap-3">
                    <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-[#005a36]">
                        @include('vehicle::partials.vehicle-type-icon', ['type' => 'car', 'class' => 'h-5 w-5', 'stroke' => '2'])
                    </span>
                    <h2 class="truncate text-lg font-bold tracking-tight sm:text-xl">Register New Vehicle</h2>
                </div>
                <button type="button" onclick="closeRegisterVehicleModal()" aria-label="Close" class="shrink-0 rounded-lg p-1.5 text-white/90 transition hover:bg-white/10 hover:text-white cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 6 6 18"/><path d="M6 6l12 12"/>
                    </svg>
                </button>
            </div>

            {{-- Step 1: form --}}
            <div id="register-vehicle-step-form" class="min-h-0 flex-1 flex-col" style="display:flex">
                <form method="POST" action="{{ route('vehicles.store') }}" id="register-vehicle-form" class="flex min-h-0 flex-1 flex-col" enctype="multipart/form-data" onsubmit="return handleRegisterVehicleSubmit(event)">
                    @csrf
                    <input type="hidden" name="_vehicle_form" value="create">

                    <div class="min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
                        <div class="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-12">

                            {{-- Vehicle Photo --}}
                            <div class="sm:col-span-6">
                                <p class="mb-2 text-sm font-bold text-slate-900">Vehicle Photo</p>
                                <div class="flex flex-col gap-3 sm:flex-row">
                                    <label
                                        for="rv-photo"
                                        id="rv-photo-dropzone"
                                        ondragover="handleRegisterPhotoDrag(event, true)"
                                        ondragleave="handleRegisterPhotoDrag(event, false)"
                                        ondrop="handleRegisterPhotoDrop(event)"
                                        class="flex h-36 min-w-0 flex-1 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50/70 px-3 text-center transition hover:border-emerald-500 hover:bg-emerald-50/40 sm:h-[204px]"
                                    >
                                        <span class="text-slate-500">
                                            @include('vehicle::partials.vehicle-type-icon', ['type' => 'car', 'class' => 'h-8 w-8', 'stroke' => '1.5'])
                                        </span>
                                        <span class="text-xs text-slate-500"><span class="font-semibold text-slate-800">Click to upload</span> or drag and drop</span>
                                        <span class="text-[11px] text-slate-400">JPG, PNG, WEBP (Max 5MB)</span>
                                    </label>
                                    <input type="file" name="photo" id="rv-photo" accept="image/png,image/jpeg,image/webp" class="hidden" onchange="handleVehiclePhotoChange(this)">

                                    <div id="rv-photo-preview" class="hidden shrink-0 sm:w-40">
                                        <div class="relative overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                                            <img id="rv-photo-preview-img" src="" alt="Selected vehicle photo" class="h-36 w-full object-cover sm:h-[168px]">
                                            <button type="button" onclick="clearRegisterPhoto()" aria-label="Remove photo" class="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-slate-900/80 text-white transition hover:bg-slate-900 cursor-pointer">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M18 6 6 18"/><path d="M6 6l12 12"/>
                                                </svg>
                                            </button>
                                        </div>
                                        <p id="rv-photo-filename" class="mt-1 truncate text-center text-[11px] font-medium text-slate-500"></p>
                                    </div>
                                </div>
                                <p id="rv-photo-error" class="mt-1.5 hidden text-xs text-red-600"></p>
                                @error('photo')
                                    <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Plate / Chassis / Engine --}}
                            <div class="space-y-4 sm:col-span-6">
                                <div>
                                    <label for="rv-plate_number" class="{{ $rvLabel }}">Plate Number <span class="text-red-500">*</span></label>
                                    <input type="text" name="plate_number" id="rv-plate_number" value="{{ $rvOld('plate_number') }}" maxlength="20" placeholder="e.g. ABC 1234" class="{{ $rvInput }} {{ $rvBorder('plate_number') }}" required>
                                    @error('plate_number')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                                <div>
                                    <label for="rv-chassis_number" class="{{ $rvLabel }}">Chassis / VIN Number <span class="text-red-500">*</span></label>
                                    <input type="text" name="chassis_number" id="rv-chassis_number" value="{{ $rvOld('chassis_number') }}" maxlength="50" placeholder="e.g. 1HGBH41JXMN109186" class="{{ $rvInput }} {{ $rvBorder('chassis_number') }}" required>
                                    @error('chassis_number')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                                <div>
                                    <label for="rv-engine_number" class="{{ $rvLabel }}">Engine Number <span class="text-red-500">*</span></label>
                                    <input type="text" name="engine_number" id="rv-engine_number" value="{{ $rvOld('engine_number') }}" maxlength="50" placeholder="e.g. 2AR1234567" class="{{ $rvInput }} {{ $rvBorder('engine_number') }}" required>
                                    @error('engine_number')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>

                            {{-- Brand --}}
                            <div class="sm:col-span-4">
                                <label for="rv-brand-select" class="{{ $rvLabel }}">Brand <span class="text-red-500">*</span></label>
                                <div class="relative">
                                    <select id="rv-brand-select" onchange="syncRegisterBrand()" class="{{ $rvSelect }} {{ $rvBorder('brand') }}" required>
                                        <option value="">Select brand</option>
                                        @foreach ($rvBrands as $brandOption)
                                            <option value="{{ $brandOption }}" @selected($rvBrandValue === $brandOption)>{{ $brandOption }}</option>
                                        @endforeach
                                        <option value="__other" @selected($rvBrandIsOther)>Other…</option>
                                    </select>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                                </div>
                                <div id="rv-brand-other-wrap" class="mt-2 {{ $rvBrandIsOther ? '' : 'hidden' }}">
                                    <input type="text" id="rv-brand-other" value="{{ $rvBrandIsOther ? $rvBrandValue : '' }}" maxlength="100" placeholder="Enter brand" oninput="syncRegisterBrand()" class="{{ $rvInput }} border-slate-200">
                                </div>
                                <input type="hidden" name="brand" id="rv-brand" value="{{ $rvBrandValue }}">
                                @error('brand')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Model --}}
                            <div class="sm:col-span-4">
                                <label for="rv-model" class="{{ $rvLabel }}">Model <span class="text-red-500">*</span></label>
                                <input type="text" name="model" id="rv-model" value="{{ $rvOld('model') }}" maxlength="100" placeholder="e.g. Civic" class="{{ $rvInput }} {{ $rvBorder('model') }}" required>
                                @error('model')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Year --}}
                            <div class="sm:col-span-4">
                                <label for="rv-year" class="{{ $rvLabel }}">Year <span class="text-red-500">*</span></label>
                                <div class="relative">
                                    <input type="number" name="year" id="rv-year" value="{{ $rvOld('year') }}" min="1900" max="{{ date('Y') + 1 }}" placeholder="e.g. 2020" class="{{ $rvInput }} {{ $rvBorder('year') }} pr-10 {{ $rvNoSpin }}" required>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/></svg>
                                </div>
                                @error('year')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Color --}}
                            <div class="sm:col-span-4">
                                <label for="rv-color" class="{{ $rvLabel }}">Color <span class="text-red-500">*</span></label>
                                <input type="text" name="color" id="rv-color" value="{{ $rvOld('color') }}" maxlength="50" placeholder="e.g. White" class="{{ $rvInput }} {{ $rvBorder('color') }}" required>
                                @error('color')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Current Odometer --}}
                            <div class="sm:col-span-4">
                                <label for="rv-odometer" class="{{ $rvLabel }}">Current Odometer <span class="text-red-500">*</span></label>
                                <div class="flex h-11 overflow-hidden rounded-lg border bg-white transition focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-600 {{ $rvBorder('odometer') }}">
                                    <div class="relative min-w-0 flex-1">
                                        <input type="number" name="odometer" id="rv-odometer" value="{{ $rvOld('odometer') }}" min="0" placeholder="e.g. 25000" class="h-full w-full border-0 bg-transparent px-3 pr-9 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-0 {{ $rvNoSpin }}" required>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/></svg>
                                    </div>
                                    <span class="flex shrink-0 items-center border-l border-slate-200 bg-slate-50 px-3 text-sm font-semibold text-slate-600">km</span>
                                </div>
                                @error('odometer')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Vehicle Type --}}
                            <div class="sm:col-span-4">
                                <label for="rv-vehicle_type" class="{{ $rvLabel }}">Vehicle Type <span class="text-red-500">*</span></label>
                                <div class="relative">
                                    <select name="vehicle_type" id="rv-vehicle_type" class="{{ $rvSelect }} {{ $rvBorder('vehicle_type') }}" required>
                                        <option value="">Select vehicle type</option>
                                        @if ($rvTypeValue !== '' && ! in_array($rvTypeValue, $rvTypes, true))
                                            <option value="{{ $rvTypeValue }}" selected>{{ $rvTypeValue }}</option>
                                        @endif
                                        @foreach ($rvTypes as $typeOption)
                                            <option value="{{ $typeOption }}" @selected($rvTypeValue === $typeOption)>{{ $typeOption }}</option>
                                        @endforeach
                                    </select>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                                </div>
                                @error('vehicle_type')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Fuel Type --}}
                            <div class="sm:col-span-5">
                                <label for="rv-fuel_type" class="{{ $rvLabel }}">Fuel Type <span class="text-red-500">*</span></label>
                                <div class="relative">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" x2="15" y1="22" y2="22"/><line x1="4" x2="14" y1="9" y2="9"/><path d="M14 22V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18"/><path d="M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5"/></svg>
                                    <select name="fuel_type" id="rv-fuel_type" class="{{ $rvSelect }} {{ $rvBorder('fuel_type') }} pl-10" required>
                                        <option value="">Select fuel type</option>
                                        @if ($rvFuelValue !== '' && ! in_array($rvFuelValue, $rvFuels, true))
                                            <option value="{{ $rvFuelValue }}" selected>{{ $rvFuelValue }}</option>
                                        @endif
                                        @foreach ($rvFuels as $fuelOption)
                                            <option value="{{ $fuelOption }}" @selected($rvFuelValue === $fuelOption)>{{ $fuelOption }}</option>
                                        @endforeach
                                    </select>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                                </div>
                                @error('fuel_type')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            {{-- Assigned Location (Super Admin editable, others read-only) --}}
                            <div class="sm:col-span-7">
                                <label for="rv-location" class="{{ $rvLabel }}">Assigned Location / Office / Province @if($isSuperAdmin)<span class="text-red-500">*</span>@endif</label>
                                <div class="relative">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                                    <select
                                        name="location"
                                        id="rv-location"
                                        @if($isSuperAdmin) required @else disabled @endif
                                        class="{{ $rvSelect }} {{ $rvBorder('location') }} pl-10 {{ $isSuperAdmin ? '' : '!cursor-not-allowed !bg-slate-50 !text-slate-500' }}"
                                    >
                                        <option value="">Select location</option>
                                        @foreach($locationOptions as $loc)
                                            <option value="{{ $loc }}" @selected(old('location', auth()->user()?->location) === $loc)>{{ $loc }}</option>
                                        @endforeach
                                    </select>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                                </div>
                                @if(!$isSuperAdmin)
                                    <input type="hidden" name="location" value="{{ auth()->user()?->location }}">
                                @endif
                                <p class="mt-1 text-xs text-slate-400">
                                    @if($isSuperAdmin)
                                        Requesters will only see this vehicle when selecting this location.
                                    @else
                                        Only a Super Admin can change the assigned location.
                                    @endif
                                </p>
                                @error('location')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>
                    </div>

                    {{-- Actions --}}
                    <div class="flex shrink-0 items-center gap-3 border-t border-slate-100 bg-white px-5 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:justify-end sm:px-6 sm:pb-4">
                        <button type="button" onclick="closeRegisterVehicleModal()" class="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 cursor-pointer sm:flex-none">
                            Cancel
                        </button>
                        <button type="submit" class="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#005a36] px-5 text-sm font-bold text-white shadow-sm transition hover:bg-[#00432a] cursor-pointer sm:flex-none">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/></svg>
                            <span>Save Vehicle</span>
                        </button>
                    </div>
                </form>
            </div>

            {{-- Step 2: confirmation --}}
            <div id="register-vehicle-step-confirm" class="min-h-0 flex-1 flex-col" style="display:none">
                <div class="min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
                    <h3 class="text-lg font-bold text-slate-900">Register this vehicle?</h3>
                    <p class="mt-1 text-sm text-slate-500">Please confirm the details below before saving the record.</p>

                    <dl class="mt-4 divide-y divide-slate-100 rounded-xl border border-slate-200 bg-slate-50/60 px-4">
                        @foreach ([
                            'plate_number'   => 'Plate Number',
                            'photo'          => 'Photo',
                            'chassis_number' => 'Chassis / VIN Number',
                            'engine_number'  => 'Engine Number',
                            'brand'          => 'Brand',
                            'model'          => 'Model',
                            'year'           => 'Year',
                            'color'          => 'Color',
                            'odometer'       => 'Odometer',
                            'vehicle_type'   => 'Vehicle Type',
                            'fuel_type'      => 'Fuel Type',
                            'location'       => 'Assigned Location',
                        ] as $confirmKey => $confirmLabel)
                            <div class="flex items-center justify-between gap-4 py-2.5">
                                <dt class="shrink-0 text-sm text-slate-500">{{ $confirmLabel }}</dt>
                                <dd id="rv-confirm-{{ $confirmKey }}" class="min-w-0 truncate text-right text-sm font-semibold text-slate-900"></dd>
                            </div>
                        @endforeach
                    </dl>
                </div>

                <div class="flex shrink-0 items-center gap-3 border-t border-slate-100 bg-white px-5 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:justify-end sm:px-6 sm:pb-4">
                    <button type="button" onclick="backToRegisterVehicleForm()" class="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 cursor-pointer sm:flex-none">
                        Back
                    </button>
                    <button type="button" onclick="confirmRegisterVehicle()" class="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#005a36] px-5 text-sm font-bold text-white shadow-sm transition hover:bg-[#00432a] cursor-pointer sm:flex-none">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/></svg>
                        <span>Save Vehicle</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    @if ($errors->any() && old('_vehicle_form') === 'create')
        <script>document.addEventListener('DOMContentLoaded', () => openRegisterVehicleModal());</script>
    @endif

    {{-- Add Vehicle Type modal --}}
    @php
        $avtActive = old('_vehicle_form') === 'type';
        $avtIcon = $avtActive ? old('icon', 'car') : 'car';
    @endphp
    <div id="add-vehicle-type-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 px-4 py-6 backdrop-blur-sm">
        <div class="flex max-h-[92vh] w-full max-w-md flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">
            <div class="flex shrink-0 items-center justify-between bg-[#005a36] px-5 py-4 text-white">
                <div class="flex min-w-0 items-center gap-3">
                    <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-[#005a36]">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
                    </span>
                    <h2 class="truncate text-lg font-bold tracking-tight">Add Vehicle Type</h2>
                </div>
                <button type="button" onclick="closeAddVehicleTypeModal()" aria-label="Close" class="shrink-0 rounded-lg p-1.5 text-white/90 transition hover:bg-white/10 hover:text-white cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="M6 6l12 12"/></svg>
                </button>
            </div>

            <form method="POST" action="{{ route('vehicles.types.store') }}" class="flex min-h-0 flex-1 flex-col">
                @csrf
                <input type="hidden" name="_vehicle_form" value="type">

                <div class="min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-5">
                    <div>
                        <label for="avt-name" class="mb-1.5 block text-[13px] font-semibold text-slate-700">Type Name <span class="text-red-500">*</span></label>
                        <input
                            type="text"
                            name="name"
                            id="avt-name"
                            value="{{ $avtActive ? old('name') : '' }}"
                            maxlength="30"
                            placeholder="e.g. Bus, Tricycle, Pickup Truck"
                            class="h-11 w-full rounded-lg border px-3 text-sm text-slate-800 placeholder-slate-400 transition focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600 {{ $avtActive && $errors->has('name') ? 'border-red-400' : 'border-slate-200' }}"
                            required
                        >
                        @if ($avtActive)
                            @error('name')
                                <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        @endif
                        <p class="mt-1 text-xs text-slate-400">Shows up as a filter on this page and as an option in the Vehicle Type dropdown.</p>
                    </div>

                    <div>
                        <span class="mb-1.5 block text-[13px] font-semibold text-slate-700">Icon <span class="text-red-500">*</span></span>
                        <div class="grid grid-cols-3 gap-2">
                            @foreach (\Modules\Vehicle\Models\VehicleType::ICONS as $avtIconKey => $avtIconLabel)
                                <label class="cursor-pointer">
                                    <input type="radio" name="icon" value="{{ $avtIconKey }}" class="peer sr-only" @checked($avtIcon === $avtIconKey) required>
                                    <span class="flex flex-col items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2 py-3 text-[11px] font-semibold text-slate-600 transition hover:bg-slate-50 peer-checked:border-[#005a36] peer-checked:bg-emerald-50 peer-checked:text-[#005a36] peer-focus-visible:ring-2 peer-focus-visible:ring-emerald-500">
                                        @include('vehicle::partials.vehicle-type-icon', ['iconOverride' => $avtIconKey, 'class' => 'h-6 w-6', 'stroke' => '1.75'])
                                        <span>{{ $avtIconLabel }}</span>
                                    </span>
                                </label>
                            @endforeach
                        </div>
                        @if ($avtActive)
                            @error('icon')
                                <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                            @enderror
                        @endif
                    </div>
                </div>

                <div class="flex shrink-0 items-center gap-3 border-t border-slate-100 bg-white px-5 py-4 sm:justify-end">
                    <button type="button" onclick="closeAddVehicleTypeModal()" class="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 cursor-pointer sm:flex-none">
                        Cancel
                    </button>
                    <button type="submit" class="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#005a36] px-5 text-sm font-bold text-white shadow-sm transition hover:bg-[#00432a] cursor-pointer sm:flex-none">
                        <span>Add Type</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if ($errors->any() && old('_vehicle_form') === 'type')
        <script>document.addEventListener('DOMContentLoaded', () => openAddVehicleTypeModal());</script>
    @endif

    {{-- Update (edit) Vehicle modal --}}
    @php
        $evIsOld      = old('_vehicle_form') === 'edit';
        $evOld        = fn (string $key, $default = '') => $evIsOld ? old($key, $default) : $default;
        $evBorder     = fn (string $field) => ($evIsOld && $errors->has($field)) ? 'border-red-400' : 'border-slate-200';

        $evBrandValue   = (string) $evOld('brand');
        $evBrandIsOther = $evBrandValue !== '' && ! in_array($evBrandValue, $rvBrands, true);
        $evTypeValue    = (string) $evOld('vehicle_type');
        $evFuelValue    = (string) $evOld('fuel_type');
    @endphp

    <div id="edit-vehicle-modal" class="fixed inset-0 z-50 hidden items-stretch justify-center bg-black/50 backdrop-blur-sm sm:items-center sm:p-6">
        <div class="flex h-full w-full flex-col overflow-hidden bg-white shadow-2xl sm:h-auto sm:max-h-[92vh] sm:max-w-3xl sm:rounded-2xl">

            {{-- Header --}}
            <div class="flex shrink-0 items-center justify-between bg-[#005a36] px-5 py-4 text-white sm:px-6">
                <div class="flex min-w-0 items-center gap-3">
                    <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-[#005a36]">
                        @include('vehicle::partials.vehicle-type-icon', ['type' => 'car', 'class' => 'h-5 w-5', 'stroke' => '2'])
                    </span>
                    <div class="min-w-0">
                        <h2 class="truncate text-lg font-bold leading-tight tracking-tight sm:text-xl">Update Vehicle Information</h2>
                        <p id="edit-vehicle-subtitle" class="truncate text-xs text-white/85 sm:text-[13px]">Edit the vehicle details and click Save to apply changes.</p>
                    </div>
                </div>
                <button type="button" onclick="closeEditVehicleModal()" aria-label="Close" class="shrink-0 rounded-lg p-1.5 text-white/90 transition hover:bg-white/10 hover:text-white cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 6 6 18"/><path d="M6 6l12 12"/>
                    </svg>
                </button>
            </div>

            <form method="POST" action="{{ old('_ev_action', route('vehicles.index')) }}" id="edit-vehicle-form" class="flex min-h-0 flex-1 flex-col" enctype="multipart/form-data" onsubmit="return handleEditVehicleSubmit(event)">
                @csrf
                @method('PUT')
                <input type="hidden" name="_vehicle_form" value="edit">
                <input type="hidden" name="_ev_action" id="edit-vehicle-action-field" value="{{ old('_ev_action') }}">
                <input type="hidden" name="remove_photo" id="ev-remove-photo" value="0">

                <div class="min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
                    <div class="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-12">

                        {{-- Vehicle Photo --}}
                        <div class="sm:col-span-5">
                            <p class="mb-2 text-sm font-bold text-slate-900">Vehicle Photo</p>

                            <div class="relative flex h-44 items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-100 text-slate-400">
                                <img id="ev-photo-preview-img" src="" alt="Vehicle photo" class="absolute inset-0 hidden h-full w-full object-cover">
                                <span id="ev-photo-preview-icon">
                                    @include('vehicle::partials.vehicle-type-icon', ['type' => 'car', 'class' => 'h-12 w-12', 'stroke' => '1.25'])
                                </span>
                                <button type="button" id="ev-photo-remove-btn" onclick="removeEditVehiclePhoto()" title="Remove photo" aria-label="Remove photo" class="absolute right-2 top-2 hidden h-8 w-8 items-center justify-center rounded-full bg-white text-red-600 shadow-md ring-1 ring-black/5 transition hover:bg-red-50 cursor-pointer">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M10 11v6M14 11v6"/>
                                    </svg>
                                </button>
                            </div>

                            <label
                                for="ev-photo"
                                id="ev-photo-dropzone"
                                ondragover="handleEditPhotoDrag(event, true)"
                                ondragleave="handleEditPhotoDrag(event, false)"
                                ondrop="handleEditPhotoDrop(event)"
                                class="mt-3 flex cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border border-dashed border-slate-300 bg-slate-50/70 px-3 py-3.5 text-center transition hover:border-emerald-500 hover:bg-emerald-50/40"
                            >
                                <span class="flex items-center gap-2 text-sm font-semibold text-slate-800">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/></svg>
                                    <span id="ev-photo-cta">Change Photo</span>
                                </span>
                                <span class="text-xs text-slate-500">Click to upload or drag and drop</span>
                                <span class="text-[11px] text-slate-400">JPG, PNG, WEBP (Max 5MB)</span>
                            </label>
                            <input type="file" name="photo" id="ev-photo" accept="image/png,image/jpeg,image/webp" class="hidden" onchange="handleEditVehiclePhotoChange(this)">
                            <p id="ev-photo-error" class="mt-1.5 hidden text-xs text-red-600"></p>
                            @if ($evIsOld)
                                @error('photo')
                                    <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            @endif
                        </div>

                        {{-- Plate / Chassis / Engine / Brand / Model / Year / Color --}}
                        <div class="grid grid-cols-1 content-start gap-x-4 gap-y-4 sm:col-span-7 sm:grid-cols-2">
                            <div class="sm:col-span-2">
                                <label for="ev-plate_number" class="{{ $rvLabel }}">Plate Number <span class="text-red-500">*</span></label>
                                <input
                                    type="text"
                                    name="plate_number"
                                    id="ev-plate_number"
                                    value="{{ $evOld('plate_number') }}"
                                    maxlength="20"
                                    placeholder="e.g. ABC 1234"
                                    @if (! $isSuperAdmin) readonly @endif
                                    class="{{ $rvInput }} {{ $evBorder('plate_number') }} {{ ! $isSuperAdmin ? '!cursor-not-allowed !bg-slate-50 !text-slate-500' : '' }}"
                                    required
                                >
                                @unless ($isSuperAdmin)
                                    <p class="mt-1 text-xs text-slate-400">Only a Super Admin can change the plate number.</p>
                                @endunless
                                @if ($evIsOld)
                                    @error('plate_number')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>

                            <div>
                                <label for="ev-chassis_number" class="{{ $rvLabel }}">Chassis / VIN Number <span class="text-red-500">*</span></label>
                                <input type="text" name="chassis_number" id="ev-chassis_number" value="{{ $evOld('chassis_number') }}" maxlength="50" placeholder="e.g. 1HGBH41JXMN109186" class="{{ $rvInput }} {{ $evBorder('chassis_number') }}" required>
                                @if ($evIsOld)
                                    @error('chassis_number')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>

                            <div>
                                <label for="ev-engine_number" class="{{ $rvLabel }}">Engine Number <span class="text-red-500">*</span></label>
                                <input type="text" name="engine_number" id="ev-engine_number" value="{{ $evOld('engine_number') }}" maxlength="50" placeholder="e.g. 2AR1234567" class="{{ $rvInput }} {{ $evBorder('engine_number') }}" required>
                                @if ($evIsOld)
                                    @error('engine_number')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>

                            {{-- Brand (dropdown with an "Other…" fallback, same as Register) --}}
                            <div>
                                <label for="ev-brand-select" class="{{ $rvLabel }}">Brand <span class="text-red-500">*</span></label>
                                <div class="relative">
                                    <select id="ev-brand-select" onchange="syncEditBrand()" class="{{ $rvSelect }} {{ $evBorder('brand') }}" required>
                                        <option value="">Select brand</option>
                                        @foreach ($rvBrands as $brandOption)
                                            <option value="{{ $brandOption }}" @selected($evBrandValue === $brandOption)>{{ $brandOption }}</option>
                                        @endforeach
                                        <option value="__other" @selected($evBrandIsOther)>Other…</option>
                                    </select>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                                </div>
                                <div id="ev-brand-other-wrap" class="mt-2 {{ $evBrandIsOther ? '' : 'hidden' }}">
                                    <input type="text" id="ev-brand-other" value="{{ $evBrandIsOther ? $evBrandValue : '' }}" maxlength="100" placeholder="Enter brand" oninput="syncEditBrand()" class="{{ $rvInput }} border-slate-200">
                                </div>
                                <input type="hidden" name="brand" id="ev-brand" value="{{ $evBrandValue }}">
                                @if ($evIsOld)
                                    @error('brand')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>

                            <div>
                                <label for="ev-model" class="{{ $rvLabel }}">Model <span class="text-red-500">*</span></label>
                                <input type="text" name="model" id="ev-model" value="{{ $evOld('model') }}" maxlength="100" placeholder="e.g. Civic" class="{{ $rvInput }} {{ $evBorder('model') }}" required>
                                @if ($evIsOld)
                                    @error('model')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>

                            <div>
                                <label for="ev-year" class="{{ $rvLabel }}">Year <span class="text-red-500">*</span></label>
                                <div class="relative">
                                    <input type="number" name="year" id="ev-year" value="{{ $evOld('year') }}" min="1900" max="{{ date('Y') + 1 }}" placeholder="e.g. 2020" class="{{ $rvInput }} {{ $evBorder('year') }} pr-10 {{ $rvNoSpin }}" required>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/></svg>
                                </div>
                                @if ($evIsOld)
                                    @error('year')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>

                            <div>
                                <label for="ev-color" class="{{ $rvLabel }}">Color <span class="text-red-500">*</span></label>
                                <input type="text" name="color" id="ev-color" value="{{ $evOld('color') }}" maxlength="50" placeholder="e.g. White" class="{{ $rvInput }} {{ $evBorder('color') }}" required>
                                @if ($evIsOld)
                                    @error('color')
                                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                    @enderror
                                @endif
                            </div>
                        </div>

                        {{-- Current Odometer --}}
                        <div class="sm:col-span-4">
                            <label for="ev-odometer" class="{{ $rvLabel }}">Current Odometer <span class="text-red-500">*</span></label>
                            <div class="flex h-11 overflow-hidden rounded-lg border bg-white transition focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-600 {{ $evBorder('odometer') }}">
                                <div class="relative min-w-0 flex-1">
                                    <input type="number" name="odometer" id="ev-odometer" value="{{ $evOld('odometer') }}" min="0" placeholder="e.g. 25000" class="h-full w-full border-0 bg-transparent px-3 pr-9 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-0 {{ $rvNoSpin }}" required>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/></svg>
                                </div>
                                <span class="flex shrink-0 items-center border-l border-slate-200 bg-slate-50 px-3 text-sm font-semibold text-slate-600">km</span>
                            </div>
                            @if ($evIsOld)
                                @error('odometer')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            @endif
                        </div>

                        {{-- Vehicle Type --}}
                        <div class="sm:col-span-4">
                            <label for="ev-vehicle_type" class="{{ $rvLabel }}">Vehicle Type <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <select name="vehicle_type" id="ev-vehicle_type" class="{{ $rvSelect }} {{ $evBorder('vehicle_type') }}" required>
                                    <option value="">Select vehicle type</option>
                                    @if ($evTypeValue !== '' && ! in_array($evTypeValue, $rvTypes, true))
                                        <option value="{{ $evTypeValue }}" selected>{{ $evTypeValue }}</option>
                                    @endif
                                    @foreach ($rvTypes as $typeOption)
                                        <option value="{{ $typeOption }}" @selected($evTypeValue === $typeOption)>{{ $typeOption }}</option>
                                    @endforeach
                                </select>
                                <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                            </div>
                            @if ($evIsOld)
                                @error('vehicle_type')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            @endif
                        </div>

                        {{-- Fuel Type --}}
                        <div class="sm:col-span-4">
                            <label for="ev-fuel_type" class="{{ $rvLabel }}">Fuel Type <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <select name="fuel_type" id="ev-fuel_type" class="{{ $rvSelect }} {{ $evBorder('fuel_type') }}" required>
                                    <option value="">Select fuel type</option>
                                    @if ($evFuelValue !== '' && ! in_array($evFuelValue, $rvFuels, true))
                                        <option value="{{ $evFuelValue }}" selected>{{ $evFuelValue }}</option>
                                    @endif
                                    @foreach ($rvFuels as $fuelOption)
                                        <option value="{{ $fuelOption }}" @selected($evFuelValue === $fuelOption)>{{ $fuelOption }}</option>
                                    @endforeach
                                </select>
                                <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                            </div>
                            @if ($evIsOld)
                                @error('fuel_type')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            @endif
                        </div>

                        {{-- Assigned Location (Super Admin editable, others read-only) --}}
                        <div class="sm:col-span-12">
                            <label for="ev-location" class="{{ $rvLabel }}">Assigned Location / Office / Province @if($isSuperAdmin)<span class="text-red-500">*</span>@endif</label>
                            <div class="relative">
                                <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                                <select
                                    name="location"
                                    id="ev-location"
                                    @if($isSuperAdmin) required @else disabled @endif
                                    class="{{ $rvSelect }} {{ $evBorder('location') }} pl-10 {{ $isSuperAdmin ? '' : '!cursor-not-allowed !bg-slate-50 !text-slate-500' }}"
                                >
                                    <option value="">Select location</option>
                                    @foreach($locationOptions as $loc)
                                        <option value="{{ $loc }}" @selected($evOld('location') === $loc)>{{ $loc }}</option>
                                    @endforeach
                                </select>
                                <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                            </div>
                            @if(!$isSuperAdmin)
                                <input type="hidden" name="location" id="ev-location-hidden">
                            @endif
                            <p class="mt-1 text-xs text-slate-400">
                                @if($isSuperAdmin)
                                    Requesters will only see this vehicle when selecting this location.
                                @else
                                    Only a Super Admin can change the assigned location.
                                @endif
                            </p>
                            @if ($evIsOld)
                                @error('location')
                                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                                @enderror
                            @endif
                        </div>

                        {{-- Record info (read-only) --}}
                        <div class="sm:col-span-12">
                            <dl class="grid grid-cols-1 gap-4 rounded-xl bg-slate-50 px-4 py-4 sm:grid-cols-2 sm:gap-0 sm:divide-x sm:divide-slate-200">
                                <div class="space-y-3 sm:pr-4">
                                    <div class="flex items-start gap-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-0.5 h-5 w-5 shrink-0 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/></svg>
                                        <div class="min-w-0">
                                            <dt class="text-[11px] text-slate-500">Date Added</dt>
                                            <dd id="ev-info-created" class="text-[13px] font-medium text-slate-800">—</dd>
                                        </div>
                                    </div>
                                    <div class="flex items-start gap-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-0.5 h-5 w-5 shrink-0 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                        <div class="min-w-0">
                                            <dt class="text-[11px] text-slate-500">Added By</dt>
                                            <dd id="ev-info-created-by" class="text-[13px] font-medium text-slate-800">—</dd>
                                        </div>
                                    </div>
                                </div>
                                <div class="space-y-3 sm:pl-4">
                                    <div class="flex items-start gap-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-0.5 h-5 w-5 shrink-0 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                                        <div class="min-w-0">
                                            <dt class="text-[11px] text-slate-500">Last Updated</dt>
                                            <dd id="ev-info-updated" class="text-[13px] font-medium text-slate-800">—</dd>
                                        </div>
                                    </div>
                                    <div class="flex items-start gap-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-0.5 h-5 w-5 shrink-0 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                        <div class="min-w-0">
                                            <dt class="text-[11px] text-slate-500">Updated By</dt>
                                            <dd id="ev-info-updated-by" class="text-[13px] font-medium text-slate-800">—</dd>
                                        </div>
                                    </div>
                                </div>
                            </dl>
                        </div>
                    </div>
                </div>

                {{-- Actions --}}
                <div class="flex shrink-0 items-center gap-3 border-t border-slate-100 bg-white px-5 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:justify-end sm:px-6 sm:pb-4">
                    <button type="button" onclick="closeEditVehicleModal()" class="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 cursor-pointer sm:flex-none">
                        Cancel
                    </button>
                    <button type="submit" class="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#005a36] px-5 text-sm font-bold text-white shadow-sm transition hover:bg-[#00432a] cursor-pointer sm:flex-none">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/></svg>
                        <span>Update Vehicle</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    @if ($errors->any() && old('_vehicle_form') === 'edit')
        <script>document.addEventListener('DOMContentLoaded', () => openEditVehicleModal(null));</script>
    @endif

    {{-- View details modal --}}
    <div id="view-vehicle-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 px-4 py-6 overflow-y-auto">
        <div class="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl my-auto">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-semibold text-gray-900">Vehicle details</h2>
                <button type="button" onclick="closeViewVehicleModal()" class="rounded-md p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 6 6 18"/><path d="M6 6l12 12"/>
                    </svg>
                </button>
            </div>

            <div class="mt-5 flex items-center gap-3">
                <div class="relative flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-emerald-50 text-emerald-600">
                    <img id="view-vehicle-photo-img" src="" alt="" class="hidden h-full w-full object-cover">
                    <svg id="view-vehicle-photo-icon" xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 13h2l2-6h10l2 6h2"/>
                        <path d="M5 13v5a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h8v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-5"/>
                        <circle cx="7.5" cy="16.5" r="1.5"/>
                        <circle cx="16.5" cy="16.5" r="1.5"/>
                    </svg>
                </div>
                <div class="min-w-0">
                    <p id="view-vehicle-title" class="truncate text-base font-semibold text-gray-900"></p>
                    <p id="view-vehicle-plate" class="truncate text-sm text-gray-500"></p>
                </div>
            </div>

            <dl class="mt-5 space-y-3 border-t border-gray-100 pt-4">
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Chassis/VIN Number</dt>
                    <dd id="view-vehicle-chassis" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Engine Number</dt>
                    <dd id="view-vehicle-engine" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Color</dt>
                    <dd id="view-vehicle-color" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Odometer</dt>
                    <dd id="view-vehicle-odometer" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Vehicle Type</dt>
                    <dd id="view-vehicle-type" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Fuel Type</dt>
                    <dd id="view-vehicle-fuel" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Registered</dt>
                    <dd id="view-vehicle-created" class="text-sm font-medium text-gray-900"></dd>
                </div>
                <div class="flex items-center justify-between">
                    <dt class="text-sm text-gray-500">Last updated</dt>
                    <dd id="view-vehicle-updated" class="text-sm font-medium text-gray-900"></dd>
                </div>
            </dl>

            <div class="mt-6 flex justify-end">
                <button
                    type="button"
                    onclick="closeViewVehicleModal()"
                    class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition"
                >
                    Close
                </button>
            </div>
        </div>
    </div>

    {{-- Delete confirmation modal --}}
    <div id="delete-vehicle-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 px-4">
        <div class="w-full max-w-sm rounded-2xl bg-white p-6 shadow-xl">
            <div class="flex h-11 w-11 items-center justify-center rounded-full bg-red-50 text-red-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 9v4M12 17h.01"/>
                    <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/>
                </svg>
            </div>

            <h2 class="mt-4 text-lg font-semibold text-gray-900">Delete vehicle?</h2>
            <p id="delete-vehicle-warning" class="mt-1 text-sm text-gray-500">
                This will permanently remove <span id="delete-vehicle-name" class="font-medium text-gray-700"></span> from the fleet. This action cannot be undone.
            </p>

            <div class="mt-6 flex justify-end gap-3">
                <button
                    type="button"
                    onclick="closeDeleteVehicleModal()"
                    class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition"
                >
                    Cancel
                </button>

                <form id="delete-vehicle-form" method="POST" action="">
                    @csrf
                    @method('DELETE')
                    <button
                        type="submit"
                        class="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-700 transition"
                    >
                        Yes, delete
                    </button>
                </form>
            </div>
        </div>
    </div>

    <style>
        .vehicle-view-toggle-btn { color: #94a3b8; }
        .vehicle-view-toggle-btn.active { background: #005a36; border-color: #005a36; color: #fff; }

        .vehicle-category-chip {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            height: 2.75rem;
            padding: 0 1rem;
            border-width: 1px;
            border-radius: 0.75rem;
            font-size: 0.75rem;
            font-weight: 700;
            line-height: 1;
            white-space: nowrap;
            cursor: pointer;
            transition: background-color .15s, border-color .15s, color .15s;
            border-color: #e2e8f0;
            background: #fff;
            color: #475569;
        }
        .vehicle-category-chip-add {
            border-style: dashed;
            border-color: #94a3b8;
            background: transparent;
            color: #005a36;
        }
        .vehicle-category-chip.vehicle-category-chip-add:hover { border-color: #005a36; background: #f0fdf4; }
        .vehicle-category-chip:hover { background: #f8fafc; }
        .vehicle-category-chip.active {
            background: #005a36;
            border-color: #005a36;
            color: #fff;
        }
    </style>

    <script>
        function applyVehicleView(mode) {
            const list = document.getElementById('vehicle-view-list');
            const grid = document.getElementById('vehicle-view-grid');
            const btnList = document.getElementById('vehicle-view-toggle-list');
            const btnGrid = document.getElementById('vehicle-view-toggle-grid');

            if (!list || !grid) return;

            if (mode === 'grid') {
                list.classList.add('hidden');
                grid.classList.remove('hidden');
                btnGrid?.classList.add('active');
                btnList?.classList.remove('active');
            } else {
                grid.classList.add('hidden');
                list.classList.remove('hidden');
                btnList?.classList.add('active');
                btnGrid?.classList.remove('active');
            }
        }

        function currentVehicleViewMode() {
            return localStorage.getItem('vehicle_view_mode') || 'list';
        }

        function setVehicleView(mode) {
            localStorage.setItem('vehicle_view_mode', mode);
            applyVehicleView(mode);
        }

        document.addEventListener('DOMContentLoaded', function () {
            applyVehicleView(currentVehicleViewMode());
            applyVehicleCategoryFilter(currentVehicleCategoryFilter());
        });

        /* ---------------- Category chip filter ---------------- */

        function currentVehicleCategoryFilter() {
            return sessionStorage.getItem('vehicle_category_filter') || 'all';
        }

        function setVehicleCategoryFilter(category) {
            sessionStorage.setItem('vehicle_category_filter', category);
            applyVehicleCategoryFilter(category);
        }

        function applyVehicleCategoryFilter(category) {
            document.querySelectorAll('.vehicle-category-chip').forEach((chip) => {
                chip.classList.toggle('active', chip.dataset.categoryFilter === category);
            });

            const cards = document.querySelectorAll('#vehicle-view-grid .vehicle-card');
            const rows = document.querySelectorAll('#vehicle-view-list .vehicle-row');
            let visibleCount = 0;

            const applyTo = (el) => {
                const matches = category === 'all' || el.dataset.category === category;
                el.classList.toggle('hidden', !matches);
                if (matches) visibleCount++;
            };

            cards.forEach(applyTo);
            rows.forEach(applyTo);

            const emptyState = document.getElementById('vehicle-empty-filter-state');
            if (emptyState) {
                emptyState.classList.toggle('hidden', visibleCount !== 0 || (cards.length === 0 && rows.length === 0));
            }
        }

        /* ---------------- Card kebab actions menu ---------------- */

        function closeAllVehicleActionsMenus() {
            document.querySelectorAll('.vehicle-actions-menu').forEach((menu) => menu.classList.add('hidden'));
        }

        function toggleVehicleActionsMenu(menuId) {
            const menu = document.getElementById(menuId);
            if (!menu) return;
            const isOpen = !menu.classList.contains('hidden');
            closeAllVehicleActionsMenus();
            if (!isOpen) menu.classList.remove('hidden');
        }

        document.addEventListener('click', function (e) {
            if (!e.target.closest('.vehicle-actions-menu') && !e.target.closest('[id^="va-menu-btn-"]')) {
                closeAllVehicleActionsMenus();
            }
        });

        /* ---------------- View modal ---------------- */

        function openViewVehicleModal(btn) {
            const img = document.getElementById('view-vehicle-photo-img');
            const icon = document.getElementById('view-vehicle-photo-icon');
            if (btn.dataset.photo) {
                img.src = btn.dataset.photo;
                img.classList.remove('hidden');
                icon.classList.add('hidden');
            } else {
                img.classList.add('hidden');
                icon.classList.remove('hidden');
            }

            document.getElementById('view-vehicle-title').textContent = btn.dataset.brand + ' ' + btn.dataset.model + ' (' + btn.dataset.year + ')';
            document.getElementById('view-vehicle-plate').textContent = btn.dataset.plate_number;
            document.getElementById('view-vehicle-chassis').textContent = btn.dataset.chassis_number;
            document.getElementById('view-vehicle-engine').textContent = btn.dataset.engine_number;
            document.getElementById('view-vehicle-color').textContent = btn.dataset.color;
            document.getElementById('view-vehicle-odometer').textContent = btn.dataset.odometer + ' km';
            document.getElementById('view-vehicle-type').textContent = btn.dataset.vehicle_type;
            document.getElementById('view-vehicle-fuel').textContent = btn.dataset.fuel_type;
            document.getElementById('view-vehicle-created').textContent = btn.dataset.created;
            document.getElementById('view-vehicle-updated').textContent = btn.dataset.updated;

            const modal = document.getElementById('view-vehicle-modal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeViewVehicleModal() {
            const modal = document.getElementById('view-vehicle-modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        /* ---------------- Delete modal ---------------- */

        function openDeleteVehicleModal(btn) {
            document.getElementById('delete-vehicle-name').textContent = btn.dataset.plate_number;
            document.getElementById('delete-vehicle-form').action = btn.dataset.deleteUrl;

            const modal = document.getElementById('delete-vehicle-modal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeDeleteVehicleModal() {
            const modal = document.getElementById('delete-vehicle-modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        /* ---------------- Edit (Update) Vehicle modal ---------------- */

        // Select a value case-insensitively. Older records may hold a value that isn't in the
        // list (e.g. "Sedan", "diesel"), so keep it selectable instead of silently wiping it.
        function setEditSelectValue(id, value) {
            const select = document.getElementById(id);
            select.querySelectorAll('option[data-legacy]').forEach((o) => o.remove());

            if (value) {
                const match = Array.from(select.options).find((o) => o.value.toLowerCase() === value.toLowerCase());
                if (match) {
                    select.value = match.value;
                    return;
                }
                const legacy = new Option(value, value, true, true);
                legacy.dataset.legacy = '1';
                select.add(legacy);
            }
            select.value = value;
        }

        // Brand: dropdown with an "Other…" free-text fallback; hidden #ev-brand carries the value.
        function syncEditBrand() {
            const select = document.getElementById('ev-brand-select');
            const other = document.getElementById('ev-brand-other');
            const wrap = document.getElementById('ev-brand-other-wrap');
            const hidden = document.getElementById('ev-brand');

            const isOther = select.value === '__other';
            wrap.classList.toggle('hidden', !isOther);
            other.required = isOther;
            hidden.value = isOther ? other.value.trim() : select.value;
        }

        function setEditBrandValue(value) {
            const select = document.getElementById('ev-brand-select');
            const other = document.getElementById('ev-brand-other');
            const match = Array.from(select.options).find((o) => o.value && o.value !== '__other' && o.value.toLowerCase() === value.toLowerCase());

            if (match) {
                select.value = match.value;
                other.value = '';
            } else if (value) {
                select.value = '__other';
                other.value = value;
            } else {
                select.value = '';
                other.value = '';
            }
            syncEditBrand();
        }

        function setEditPhotoState(src) {
            const img = document.getElementById('ev-photo-preview-img');
            const icon = document.getElementById('ev-photo-preview-icon');
            const removeBtn = document.getElementById('ev-photo-remove-btn');
            const cta = document.getElementById('ev-photo-cta');

            if (src) {
                img.src = src;
                img.classList.remove('hidden');
                icon.classList.add('hidden');
                removeBtn.classList.remove('hidden');
                removeBtn.classList.add('flex');
                cta.textContent = 'Change Photo';
            } else {
                img.src = '';
                img.classList.add('hidden');
                icon.classList.remove('hidden');
                removeBtn.classList.add('hidden');
                removeBtn.classList.remove('flex');
                cta.textContent = 'Upload Photo';
            }
        }

        function setEditPhotoError(message) {
            const el = document.getElementById('ev-photo-error');
            el.textContent = message || '';
            el.classList.toggle('hidden', !message);
        }

        function openEditVehicleModal(btn) {
            const modal = document.getElementById('edit-vehicle-modal');
            const form = document.getElementById('edit-vehicle-form');

            document.getElementById('ev-photo').value = '';
            document.getElementById('ev-remove-photo').value = '0';
            setEditPhotoError('');

            if (btn) {
                form.action = btn.dataset.updateUrl;
                document.getElementById('edit-vehicle-action-field').value = btn.dataset.updateUrl;
                document.getElementById('edit-vehicle-subtitle').textContent = 'Edit the details of ' + btn.dataset.plate_number + ' and click Save to apply changes.';

                document.getElementById('ev-plate_number').value = btn.dataset.plate_number;
                document.getElementById('ev-chassis_number').value = btn.dataset.chassis_number;
                document.getElementById('ev-engine_number').value = btn.dataset.engine_number;
                setEditBrandValue(btn.dataset.brand || '');
                document.getElementById('ev-model').value = btn.dataset.model;
                document.getElementById('ev-year').value = btn.dataset.year;
                document.getElementById('ev-color').value = btn.dataset.color;
                document.getElementById('ev-odometer').value = btn.dataset.odometer;
                setEditSelectValue('ev-vehicle_type', btn.dataset.vehicle_type || '');
                setEditSelectValue('ev-fuel_type', btn.dataset.fuel_type || '');

                const locVal = btn.dataset.location || '';
                document.getElementById('ev-location').value = locVal;
                const evLocHidden = document.getElementById('ev-location-hidden');
                if (evLocHidden) {
                    evLocHidden.value = locVal;
                }

                setEditPhotoState(btn.dataset.photo || '');

                const info = (id, value) => { document.getElementById(id).textContent = value || '—'; };
                info('ev-info-created', btn.dataset.created);
                info('ev-info-created-by', btn.dataset.createdBy);
                info('ev-info-updated', btn.dataset.updated);
                info('ev-info-updated-by', btn.dataset.updatedBy);
            } else {
                // Re-opened automatically after a validation error: values were rendered server-side.
                syncEditBrand();
                setEditPhotoState('');
            }

            modal.classList.remove('hidden');
            modal.classList.add('flex');
            document.body.classList.add('overflow-hidden');
        }

        function closeEditVehicleModal() {
            const modal = document.getElementById('edit-vehicle-modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.body.classList.remove('overflow-hidden');
        }

        function handleEditVehiclePhotoChange(input) {
            const file = input.files && input.files[0];
            setEditPhotoError('');
            if (!file) return;

            if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
                input.value = '';
                setEditPhotoError('Please choose a JPG, PNG or WEBP image.');
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                input.value = '';
                setEditPhotoError('That image is larger than 5MB. Please choose a smaller one.');
                return;
            }

            document.getElementById('ev-remove-photo').value = '0';

            const reader = new FileReader();
            reader.onload = (e) => setEditPhotoState(e.target.result);
            reader.readAsDataURL(file);
        }

        function removeEditVehiclePhoto() {
            document.getElementById('ev-photo').value = '';
            document.getElementById('ev-remove-photo').value = '1';
            setEditPhotoError('');
            setEditPhotoState('');
        }

        function handleEditPhotoDrag(event, active) {
            event.preventDefault();
            const zone = document.getElementById('ev-photo-dropzone');
            zone.classList.toggle('border-emerald-500', active);
            zone.classList.toggle('bg-emerald-50/40', active);
        }

        function handleEditPhotoDrop(event) {
            event.preventDefault();
            handleEditPhotoDrag(event, false);

            const file = event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0];
            if (!file) return;

            const input = document.getElementById('ev-photo');
            const transfer = new DataTransfer();
            transfer.items.add(file);
            input.files = transfer.files;
            handleEditVehiclePhotoChange(input);
        }

        function handleEditVehicleSubmit(event) {
            syncEditBrand();
            return event.target.reportValidity();
        }

        /* ---------------- Live search ---------------- */

        let vehicleSearchTimer = null;
        let vehicleSearchController = null;

        function onVehicleSearchInput() {
            const value = document.getElementById('vehicle-search-input').value;
            document.getElementById('vehicle-search-clear').classList.toggle('hidden', value.length === 0);

            clearTimeout(vehicleSearchTimer);
            vehicleSearchTimer = setTimeout(() => runVehicleSearch(value), 300);
        }

        function toggleVehicleLocationMenu() {
            const menu = document.getElementById('vehicle-location-menu');
            const chevron = document.getElementById('vehicle-location-chevron');
            if (menu.classList.contains('hidden')) {
                menu.classList.remove('hidden');
                chevron?.classList.add('rotate-180');
            } else {
                menu.classList.add('hidden');
                chevron?.classList.remove('rotate-180');
            }
        }

        document.addEventListener('click', function (e) {
            const menu = document.getElementById('vehicle-location-menu');
            const btn = e.target.closest('button[onclick="toggleVehicleLocationMenu()"]');
            if (menu && !menu.classList.contains('hidden') && !btn && !menu.contains(e.target)) {
                menu.classList.add('hidden');
                document.getElementById('vehicle-location-chevron')?.classList.remove('rotate-180');
            }
        });

        function clearVehicleSearch(event) {
            event.preventDefault();
            document.getElementById('vehicle-search-input').value = '';
            document.getElementById('vehicle-search-clear').classList.add('hidden');
            runVehicleSearch('');
            return false;
        }

        function runVehicleSearch(term) {
            const url = new URL(window.location.href);
            if (term) {
                url.searchParams.set('search', term);
            } else {
                url.searchParams.delete('search');
            }
            url.searchParams.delete('page');

            const spinner = document.getElementById('vehicle-search-spinner');
            spinner.classList.remove('hidden');

            if (vehicleSearchController) {
                vehicleSearchController.abort();
            }
            vehicleSearchController = new AbortController();

            fetch(url.toString(), {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                signal: vehicleSearchController.signal,
            })
                .then((response) => response.text())
                .then((html) => {
                    const doc = new DOMParser().parseFromString(html, 'text/html');
                    const fresh = doc.getElementById('vehicle-results');
                    if (fresh) {
                        document.getElementById('vehicle-results').innerHTML = fresh.innerHTML;
                        applyVehicleView(currentVehicleViewMode());
                        applyVehicleCategoryFilter(currentVehicleCategoryFilter());
                    }
                    window.history.replaceState({}, '', url.toString());
                })
                .catch((error) => {
                    if (error.name !== 'AbortError') {
                        console.error('Vehicle search failed', error);
                    }
                })
                .finally(() => {
                    spinner.classList.add('hidden');
                });
        }

        function goToVehiclePage(page) {
            const url = new URL(window.location.href);
            url.searchParams.set('page', page);
            fetchAndSwapVehicleResults(url.toString());
        }

        function changeVehiclePerPage(size) {
            const url = new URL(window.location.href);
            url.searchParams.set('per_page', size);
            url.searchParams.set('page', '1');
            fetchAndSwapVehicleResults(url.toString());
        }

        function fetchAndSwapVehicleResults(urlStr) {
            const spinner = document.getElementById('vehicle-search-spinner');
            spinner?.classList.remove('hidden');

            fetch(urlStr, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(res => res.text())
                .then(html => {
                    const doc = new DOMParser().parseFromString(html, 'text/html');
                    const fresh = doc.getElementById('vehicle-results');
                    if (fresh) {
                        document.getElementById('vehicle-results').innerHTML = fresh.innerHTML;
                        applyVehicleView(currentVehicleViewMode());
                        applyVehicleCategoryFilter(currentVehicleCategoryFilter());
                    }
                    window.history.pushState({}, '', urlStr);
                })
                .catch(err => console.error('Vehicle fetch error:', err))
                .finally(() => spinner?.classList.add('hidden'));
        }
    </script>

    <script>
        const RV_MAX_PHOTO_BYTES = 5 * 1024 * 1024;
        const RV_PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

        function showRegisterStep(step) {
            document.getElementById('register-vehicle-step-form').style.display = step === 'form' ? 'flex' : 'none';
            document.getElementById('register-vehicle-step-confirm').style.display = step === 'confirm' ? 'flex' : 'none';
        }

        function openRegisterVehicleModal() {
            const modal = document.getElementById('register-vehicle-modal');
            showRegisterStep('form');
            syncRegisterBrand();
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            document.body.classList.add('overflow-hidden');
        }

        function closeRegisterVehicleModal() {
            const modal = document.getElementById('register-vehicle-modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.body.classList.remove('overflow-hidden');
        }

        // Brand: dropdown with an "Other…" free-text fallback. The hidden #rv-brand input carries the final value.
        function syncRegisterBrand() {
            const select = document.getElementById('rv-brand-select');
            const other = document.getElementById('rv-brand-other');
            const wrap = document.getElementById('rv-brand-other-wrap');
            const hidden = document.getElementById('rv-brand');
            if (!select || !other || !wrap || !hidden) return;

            const isOther = select.value === '__other';
            wrap.classList.toggle('hidden', !isOther);
            other.required = isOther;
            hidden.value = isOther ? other.value.trim() : select.value;
        }

        function setRegisterPhotoError(message) {
            const el = document.getElementById('rv-photo-error');
            el.textContent = message || '';
            el.classList.toggle('hidden', !message);
        }

        function resetRegisterPhotoPreview() {
            document.getElementById('rv-photo-preview-img').src = '';
            document.getElementById('rv-photo-filename').textContent = '';
            document.getElementById('rv-photo-preview').classList.add('hidden');
        }

        function handleVehiclePhotoChange(input) {
            const file = input.files && input.files[0];
            setRegisterPhotoError('');

            if (!file) {
                resetRegisterPhotoPreview();
                return;
            }

            if (!RV_PHOTO_TYPES.includes(file.type)) {
                input.value = '';
                resetRegisterPhotoPreview();
                setRegisterPhotoError('Please choose a JPG, PNG or WEBP image.');
                return;
            }

            if (file.size > RV_MAX_PHOTO_BYTES) {
                input.value = '';
                resetRegisterPhotoPreview();
                setRegisterPhotoError('That image is larger than 5MB. Please choose a smaller one.');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                document.getElementById('rv-photo-preview-img').src = e.target.result;
                document.getElementById('rv-photo-filename').textContent = file.name;
                document.getElementById('rv-photo-preview').classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        }

        function clearRegisterPhoto() {
            document.getElementById('rv-photo').value = '';
            setRegisterPhotoError('');
            resetRegisterPhotoPreview();
        }

        function handleRegisterPhotoDrag(event, active) {
            event.preventDefault();
            const zone = document.getElementById('rv-photo-dropzone');
            zone.classList.toggle('border-emerald-500', active);
            zone.classList.toggle('bg-emerald-50/40', active);
        }

        function handleRegisterPhotoDrop(event) {
            event.preventDefault();
            handleRegisterPhotoDrag(event, false);

            const file = event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0];
            if (!file) return;

            const input = document.getElementById('rv-photo');
            const transfer = new DataTransfer();
            transfer.items.add(file);
            input.files = transfer.files;
            handleVehiclePhotoChange(input);
        }

        function handleRegisterVehicleSubmit(event) {
            event.preventDefault();
            const form = document.getElementById('register-vehicle-form');

            syncRegisterBrand();

            if (!form.reportValidity()) {
                return false;
            }

            const value = (id) => document.getElementById(id).value;
            const setConfirm = (key, text) => {
                document.getElementById('rv-confirm-' + key).textContent = text || 'None';
            };

            const photoFile = document.getElementById('rv-photo').files[0];

            setConfirm('plate_number', value('rv-plate_number'));
            setConfirm('photo', photoFile ? photoFile.name : '');
            setConfirm('chassis_number', value('rv-chassis_number'));
            setConfirm('engine_number', value('rv-engine_number'));
            setConfirm('brand', value('rv-brand'));
            setConfirm('model', value('rv-model'));
            setConfirm('year', value('rv-year'));
            setConfirm('color', value('rv-color'));
            setConfirm('odometer', value('rv-odometer') + ' km');
            setConfirm('vehicle_type', value('rv-vehicle_type'));
            setConfirm('fuel_type', value('rv-fuel_type'));
            setConfirm('location', value('rv-location'));

            showRegisterStep('confirm');
            return false;
        }

        function backToRegisterVehicleForm() {
            showRegisterStep('form');
        }

        function confirmRegisterVehicle() {
            syncRegisterBrand();
            document.getElementById('register-vehicle-form').submit();
        }

        document.addEventListener('DOMContentLoaded', syncRegisterBrand);
    </script>
    <script>
        function openAddVehicleTypeModal() {
            const modal = document.getElementById('add-vehicle-type-modal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            document.body.classList.add('overflow-hidden');
            document.getElementById('avt-name')?.focus();
        }

        function closeAddVehicleTypeModal() {
            const modal = document.getElementById('add-vehicle-type-modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.body.classList.remove('overflow-hidden');
        }
    </script>
@endsection
