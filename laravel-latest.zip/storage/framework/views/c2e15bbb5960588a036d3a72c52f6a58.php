<?php $__env->startSection('title', 'My Profile'); ?>
<?php $__env->startSection('page-title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $initial = strtoupper(substr($user->name, 0, 1));
        $locationLabel = $user->location ?: ($user->role?->value === 'super_admin' ? 'All Locations (Super Admin)' : 'Not assigned');
    ?>

    <div class="space-y-4">
        
        <div>
            <h1 class="text-2xl font-extrabold tracking-tight text-slate-900">My Profile</h1>
            <p class="text-sm text-slate-500">Manage your personal account settings and credentials</p>
        </div>

        <form method="POST" action="<?php echo e(route('my-profile.update')); ?>" enctype="multipart/form-data" class="mx-auto max-w-3xl overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="h-16 bg-gradient-to-br from-[#155f35] via-[#1d8148] to-[#269d59]"></div>

            <div class="-mt-9 px-5 pb-4 sm:px-6">
                <div class="flex flex-col items-center text-center">
                    <div class="relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-4 border-white bg-emerald-700 text-3xl font-extrabold text-white shadow-lg ring-1 ring-emerald-100">
                        <?php if($user->avatar_url): ?>
                            <img src="<?php echo e($user->avatar_url); ?>" alt="<?php echo e($user->name); ?>" class="h-full w-full object-cover">
                        <?php else: ?>
                            <?php echo e($initial); ?>

                        <?php endif; ?>
                    </div>
                    <input id="profile-avatar" type="file" name="avatar" accept="image/*" class="hidden">
                    <input id="remove-avatar" type="checkbox" name="remove_avatar" value="1" class="hidden">
                    <p class="mt-1.5 text-xs text-gray-500">Photo (max 5MB)</p>

                    <h3 class="mt-1 text-lg font-extrabold text-gray-900"><?php echo e($user->name); ?></h3>
                    <p class="mt-0.5 text-sm text-gray-500">
                        <span class="rounded-full bg-violet-50 px-2 py-0.5 text-xs font-semibold text-violet-700"><?php echo e($user->role?->label()); ?></span>
                        <span class="mx-1">•</span><?php echo e($user->email); ?>

                    </p>

                    <div class="mt-2 flex flex-wrap items-center justify-center gap-2">
                        <label for="profile-avatar" class="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
                                <path d="M3 21v-5h5"/>
                                <path d="M3 12a9 9 0 0 1 15.56-6.26L21 8"/>
                                <path d="M16 8h5V3"/>
                            </svg>
                            Replace
                        </label>
                        <?php if($user->avatar_url): ?>
                            <button type="button" onclick="document.getElementById('remove-avatar').checked = true; this.classList.add('bg-red-600','text-white'); this.classList.remove('bg-red-50','text-red-700');" class="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-bold text-red-700 transition hover:bg-red-100">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M3 6h18"/>
                                    <path d="M8 6V4h8v2"/>
                                    <path d="m19 6-1 14H6L5 6"/>
                                </svg>
                                Remove
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mt-4 grid gap-4 md:grid-cols-2 text-left">
                    
                    <section class="rounded-xl border border-gray-100 bg-gray-50/70 p-4">
                        <div class="mb-3 border-b border-gray-200/60 pb-2">
                            <h4 class="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-slate-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-emerald-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="8" r="4"/>
                                    <path d="M5.5 21a6.5 6.5 0 0 1 13 0"/>
                                </svg>
                                Account Credentials
                            </h4>
                        </div>

                        <div class="space-y-3">
                            <div>
                                <label class="mb-1 flex items-center gap-1 text-[11px] font-bold text-gray-700">
                                    Full Name <span class="text-red-500">*</span>
                                </label>
                                <input name="name" value="<?php echo e(old('name', $user->name)); ?>" required class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-[11px] text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div>
                                <label class="mb-1 flex items-center gap-1 text-[11px] font-bold text-gray-700">
                                    Phone Number <span class="text-red-500">*</span>
                                </label>
                                <input name="phone_number" value="<?php echo e(old('phone_number', $user->phone_number)); ?>" required class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500">
                                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-[11px] text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div>
                                <label class="mb-1 flex items-center gap-1 text-[11px] font-bold text-gray-700">
                                    Email Address
                                </label>
                                <div class="relative">
                                    <input value="<?php echo e($user->email); ?>" disabled class="w-full rounded-lg border border-gray-200 bg-gray-100/70 px-3 py-2 pr-8 text-xs text-gray-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <rect width="18" height="11" x="3" y="11" rx="2"/>
                                        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                                    </svg>
                                </div>
                                <p class="mt-1 text-[10px] text-gray-400">Account email is managed by your administrator.</p>
                            </div>

                            <div>
                                <label class="mb-1 flex items-center gap-1 text-[11px] font-bold text-gray-700">
                                    Assigned Location / Office Province
                                </label>
                                <div class="relative">
                                    <input value="<?php echo e($locationLabel); ?>" disabled class="w-full rounded-lg border border-gray-200 bg-gray-100/70 px-3 py-2 pr-8 text-xs text-gray-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <rect width="18" height="11" x="3" y="11" rx="2"/>
                                        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                                    </svg>
                                </div>
                                <p class="mt-1 text-[10px] text-gray-400">Office assignment is managed by your administrator.</p>
                            </div>
                        </div>
                    </section>

                    
                    <section class="rounded-xl border border-gray-100 bg-gray-50/70 p-4">
                        <div class="mb-3 border-b border-gray-200/60 pb-2">
                            <h4 class="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-slate-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-emerald-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                                    <circle cx="9" cy="7" r="4"/>
                                </svg>
                                Driver Details
                            </h4>
                        </div>

                        <div class="space-y-3">
                            <div>
                                <label class="mb-1 block text-[11px] font-bold text-gray-700">Birth Date</label>
                                <input type="date" name="birth_date" value="<?php echo e(old('birth_date', optional($user->birth_date)->format('Y-m-d'))); ?>" class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500">
                            </div>

                            <div>
                                <label class="mb-1 block text-[11px] font-bold text-gray-700">Residential Address</label>
                                <input name="address" value="<?php echo e(old('address', $user->address)); ?>" placeholder="e.g. Calapan City, Oriental Mindoro" class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-xs focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500">
                            </div>

                            <div>
                                <label class="mb-1 block text-[11px] font-bold text-gray-700">Driver's License Number</label>
                                <div class="relative">
                                    <input value="<?php echo e($user->license_number ?: 'Not set'); ?>" disabled class="w-full rounded-lg border border-gray-200 bg-gray-100/70 px-3 py-2 pr-8 text-xs text-gray-600 font-medium">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <rect width="18" height="11" x="3" y="11" rx="2"/>
                                        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                                    </svg>
                                </div>
                            </div>

                            <div>
                                <label class="mb-1 block text-[11px] font-bold text-gray-700">Driver's License Expiration</label>
                                <div class="relative">
                                    <?php
                                        $expDate = $user->license_expiration_date;
                                        $daysLeft = $expDate ? (int) round(now()->startOfDay()->diffInDays($expDate->startOfDay(), false)) : null;
                                        $isExp = !is_null($daysLeft) && $daysLeft < 0;
                                        $isUrgent = !is_null($daysLeft) && $daysLeft >= 0 && $daysLeft <= 7;
                                        $isWarning = !is_null($daysLeft) && $daysLeft > 7 && $daysLeft <= 30;
                                    ?>
                                    <input value="<?php echo e(optional($expDate)->format('Y-m-d') ?: 'Not set'); ?>" disabled class="w-full rounded-lg border <?php echo e($isExp || $isUrgent ? 'border-red-300 bg-red-50/50' : ($isWarning ? 'border-amber-300 bg-amber-50/50' : 'border-gray-200 bg-gray-100/70')); ?> px-3 py-2 pr-32 text-xs text-gray-700 font-semibold">
                                    <?php if($expDate): ?>
                                        <span class="absolute right-2 top-1/2 -translate-y-1/2 rounded-md px-2 py-0.5 text-[9px] font-extrabold uppercase <?php echo e($isExp ? 'bg-red-600 text-white' : ($isUrgent ? 'bg-red-600 text-white animate-pulse' : ($isWarning ? 'bg-amber-500 text-white' : 'bg-emerald-100 text-emerald-800'))); ?>">
                                            <?php if($isExp): ?>
                                                EXPIRED
                                            <?php elseif($isUrgent || $isWarning): ?>
                                                EXPIRES IN <?php echo e($daysLeft); ?> <?php echo e(Illuminate\Support\Str::plural('DAY', $daysLeft)); ?>

                                            <?php else: ?>
                                                ✓ VALID
                                            <?php endif; ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <?php if($isExp): ?>
                                    <p class="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-red-600">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-red-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                        License expired on <?php echo e($expDate->format('M d, Y')); ?>! Please submit your renewed license to your administrator.
                                    </p>
                                <?php elseif($isUrgent): ?>
                                    <p class="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-red-600">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-red-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                        Urgent: Your license expires in <?php echo e($daysLeft); ?> <?php echo e(Illuminate\Support\Str::plural('day', $daysLeft)); ?> (<?php echo e($expDate->format('M d, Y')); ?>)!
                                    </p>
                                <?php elseif($isWarning): ?>
                                    <p class="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-amber-700">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-amber-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                        Notice: License expires in <?php echo e($daysLeft); ?> <?php echo e(Illuminate\Support\Str::plural('day', $daysLeft)); ?> (<?php echo e($expDate->format('M d, Y')); ?>).
                                    </p>
                                <?php else: ?>
                                    <p class="mt-1 text-[10px] text-gray-400">Managed and verified by your fleet administrator.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="mt-5 flex justify-end border-t border-gray-100 pt-4">
                    <button type="submit" class="inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-emerald-700 px-5 py-2.5 text-xs font-extrabold text-white shadow-md hover:bg-emerald-800 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 6 9 17l-5-5"/>
                        </svg>
                        Save Changes
                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\resources\views/profile/edit.blade.php ENDPATH**/ ?>