<?php if($admins->isEmpty()): ?>
    <div class="rounded-xl border border-dashed border-gray-300 bg-white px-6 py-14 text-center">
        <p class="text-sm font-bold text-gray-900">No admins found</p>
        <p class="mt-1 text-sm text-gray-500">
            <?php if(request('search')): ?>
                No results match "<?php echo e(request('search')); ?>".
            <?php else: ?>
                Get started by adding your first admin.
            <?php endif; ?>
        </p>
    </div>
<?php else: ?>
    <div id="admin-view-list" class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Name</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Email</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Role</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Assigned Location</th>
                        <th class="whitespace-nowrap px-4 py-3 text-right text-xs font-bold uppercase tracking-wide text-slate-500">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $initial = Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($admin->name, 0, 1));
                            $isCurrent = auth()->id() === $admin->id;
                            $location = $admin->role === \Modules\Admin\Enums\UserRole::SUPER_ADMIN ? 'All (Super Admin)' : ($admin->location ?: 'Not assigned');
                            $officer = $admin->location ? ($approvingOfficers->get($admin->location) ?? null) : null;
                        ?>
                        <tr class="<?php echo e($isCurrent ? 'bg-emerald-50/50' : 'hover:bg-gray-50/70'); ?>">
                            <td class="whitespace-nowrap px-4 py-3">
                                <div class="flex items-center gap-3">
                                    <?php if($admin->avatar_url): ?>
                                        <img src="<?php echo e($admin->avatar_url); ?>" alt="<?php echo e($admin->name); ?>" class="h-9 w-9 shrink-0 rounded-full object-cover ring-1 ring-gray-200">
                                    <?php else: ?>
                                        <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-700 text-xs font-bold text-white">
                                            <?php echo e($initial); ?>

                                        </div>
                                    <?php endif; ?>
                                    <span class="text-sm font-semibold text-gray-900"><?php echo e($admin->name); ?><?php if($isCurrent): ?> <span class="font-normal text-gray-500">(you)</span><?php endif; ?></span>
                                </div>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3 text-sm text-slate-600"><?php echo e($admin->email); ?></td>
                            <td class="whitespace-nowrap px-4 py-3">
                                <?php if (isset($component)) { $__componentOriginalb954e539ebbc4c303f4792091c53fd5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.role-badge','data' => ['role' => $admin->role]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::role-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin->role)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $attributes = $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $component = $__componentOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3 text-sm italic text-slate-500"><?php echo e($location); ?></td>
                            <td class="whitespace-nowrap px-4 py-3 text-right">
                                <?php if (isset($component)) { $__componentOriginala24a7c221641f08078ec61e81b617907 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala24a7c221641f08078ec61e81b617907 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.row-actions','data' => ['admin' => $admin,'officer' => $officer]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin),'officer' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($officer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala24a7c221641f08078ec61e81b617907)): ?>
<?php $attributes = $__attributesOriginala24a7c221641f08078ec61e81b617907; ?>
<?php unset($__attributesOriginala24a7c221641f08078ec61e81b617907); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala24a7c221641f08078ec61e81b617907)): ?>
<?php $component = $__componentOriginala24a7c221641f08078ec61e81b617907; ?>
<?php unset($__componentOriginala24a7c221641f08078ec61e81b617907); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="admin-view-grid" class="hidden grid grid-cols-1 gap-3 md:grid-cols-3 2xl:grid-cols-5">
        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $initial = Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($admin->name, 0, 1));
                $isCurrent = auth()->id() === $admin->id;
                $location = $admin->role === \Modules\Admin\Enums\UserRole::SUPER_ADMIN ? 'All (Super Admin)' : ($admin->location ?: 'Not assigned');
                $officer = $admin->location ? ($approvingOfficers->get($admin->location) ?? null) : null;
            ?>
            <article class="rounded-xl border border-gray-200 bg-white p-3 shadow-sm transition hover:border-emerald-200 hover:shadow-md">
                <div class="flex items-start gap-2.5">
                    <?php if($admin->avatar_url): ?>
                        <img src="<?php echo e($admin->avatar_url); ?>" alt="<?php echo e($admin->name); ?>" class="h-10 w-10 shrink-0 rounded-full object-cover ring-1 ring-gray-200">
                    <?php else: ?>
                        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-700 text-sm font-bold text-white">
                            <?php echo e($initial); ?>

                        </div>
                    <?php endif; ?>
                    <div class="min-w-0 flex-1">
                        <div class="flex flex-wrap items-center gap-2">
                            <h3 class="truncate text-sm font-extrabold text-gray-900"><?php echo e($admin->name); ?><?php if($isCurrent): ?> <span class="font-normal text-gray-500">(you)</span><?php endif; ?></h3>
                            <?php if (isset($component)) { $__componentOriginalb954e539ebbc4c303f4792091c53fd5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'admin::components.role-badge','data' => ['role' => $admin->role]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin::role-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin->role)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $attributes = $__attributesOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__attributesOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a)): ?>
<?php $component = $__componentOriginalb954e539ebbc4c303f4792091c53fd5a; ?>
<?php unset($__componentOriginalb954e539ebbc4c303f4792091c53fd5a); ?>
<?php endif; ?>
                        </div>
                        <p class="mt-2 flex items-center gap-1.5 truncate text-xs text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"/>
                                <rect x="2" y="4" width="20" height="16" rx="2"/>
                            </svg>
                            <?php echo e($admin->email); ?>

                        </p>
                        <p class="mt-2 flex items-center gap-1.5 truncate text-xs text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-pink-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/>
                                <circle cx="12" cy="10" r="3"/>
                            </svg>
                            <?php echo e($location); ?>

                        </p>
                    </div>
                </div>

                <div class="mt-3 grid grid-cols-2 gap-2">
                    <button type="button" onclick="openEditAdminModal(this)" data-name="<?php echo e($admin->name); ?>" data-email="<?php echo e($admin->email); ?>" data-avatar="<?php echo e($admin->avatar_url); ?>" data-initial="<?php echo e($initial); ?>" data-role-value="<?php echo e($admin->role->value); ?>" data-phone-number="<?php echo e($admin->phone_number); ?>" data-location="<?php echo e($admin->location); ?>" data-signee1-name="<?php echo e($officer?->signee1_name); ?>" data-signee1-title="<?php echo e($officer?->signee1_title); ?>" data-signee2-name="<?php echo e($officer?->signee2_name); ?>" data-signee2-title="<?php echo e($officer?->signee2_title); ?>" data-update-url="<?php echo e(route('admin.update', $admin)); ?>" class="inline-flex items-center justify-center gap-1.5 rounded-lg border border-blue-100 px-2 py-2 text-xs font-semibold text-blue-700 transition hover:bg-blue-50">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                            <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5Z"/>
                        </svg>
                        Edit
                    </button>
                    <button type="button" onclick="openDeleteModal(this)" data-name="<?php echo e($admin->name); ?>" data-delete-url="<?php echo e(route('admin.destroy', $admin)); ?>" class="inline-flex items-center justify-center gap-1.5 rounded-lg border border-red-100 px-2 py-2 text-xs font-semibold text-red-600 transition hover:bg-red-50">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 6h18"/>
                            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
                        </svg>
                        Delete
                    </button>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-4 flex flex-col gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3 shadow-sm sm:flex-row sm:items-center sm:justify-between">
        <div class="flex flex-wrap items-center gap-4 text-xs text-slate-500 font-medium">
            <div>
                Showing <span class="font-bold text-slate-700"><?php echo e($admins->firstItem() ?? 0); ?></span> to <span class="font-bold text-slate-700"><?php echo e($admins->lastItem() ?? 0); ?></span> of <span class="font-bold text-slate-700"><?php echo e($admins->total()); ?></span> admins
            </div>

            <div class="flex items-center gap-2">
                <span>Rows per page:</span>
                <select id="admin-per-page-select" onchange="changePerPage(this.value)" class="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-semibold text-slate-700 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer">
                    <?php $__currentLoopData = [10, 15, 20, 25, 50, 75, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="flex items-center gap-1">
            <button type="button" onclick="goToAdminPage(1)" <?php if($admins->onFirstPage()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &laquo;
            </button>
            <button type="button" onclick="goToAdminPage(<?php echo e(max(1, $admins->currentPage() - 1)); ?>)" <?php if($admins->onFirstPage()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &lt;
            </button>

            <?php $__currentLoopData = $admins->getUrlRange(max(1, $admins->currentPage() - 1), min($admins->lastPage(), $admins->currentPage() + 1)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" onclick="goToAdminPage(<?php echo e($page); ?>)" class="inline-flex h-7 w-7 items-center justify-center rounded-lg border text-xs font-bold transition <?php echo e($page == $admins->currentPage() ? 'bg-emerald-700 text-white border-emerald-700' : 'border-slate-200 text-slate-700 hover:bg-slate-50'); ?>">
                    <?php echo e($page); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="button" onclick="goToAdminPage(<?php echo e(min($admins->lastPage(), $admins->currentPage() + 1)); ?>)" <?php if(!$admins->hasMorePages()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &gt;
            </button>
            <button type="button" onclick="goToAdminPage(<?php echo e($admins->lastPage()); ?>)" <?php if(!$admins->hasMorePages()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &raquo;
            </button>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Admin\Providers/../Views/partials/admin-results.blade.php ENDPATH**/ ?>