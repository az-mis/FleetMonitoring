<?php $__env->startSection('title', 'Maintenance'); ?>
<?php $__env->startSection('page-title', 'Maintenance'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $locationOptions = [
        'Oriental Mindoro',
        'Occidental Mindoro',
        'Marinduque',
        'Palawan',
        'Romblon',
        'Quezon City Satellite Office',
    ];

    $statusStyles = [
        'scheduled' => ['label' => 'Scheduled', 'bg' => 'bg-sky-100',   'text' => 'text-sky-700',   'ring' => 'ring-sky-200'],
        'ongoing'   => ['label' => 'Ongoing',   'bg' => 'bg-orange-100', 'text' => 'text-orange-700','ring' => 'ring-orange-200'],
        'completed' => ['label' => 'Completed', 'bg' => 'bg-green-100',  'text' => 'text-green-700', 'ring' => 'ring-green-200'],
        'cancelled' => ['label' => 'Cancelled', 'bg' => 'bg-slate-100',  'text' => 'text-slate-500', 'ring' => 'ring-slate-200'],
    ];

    $priorityStyles = [
        'normal' => ['label' => 'Normal', 'text' => 'text-green-700'],
        'high'   => ['label' => 'High',   'text' => 'text-amber-600'],
        'urgent' => ['label' => 'Urgent', 'text' => 'text-red-600'],
    ];

    $maintenanceTypes = ['Preventive','Repair','Inspection','Oil Change','Tire','Battery','Other'];
    $statusFilters    = ['active','scheduled','ongoing','completed','cancelled','all'];

    $editRecord = session('edit_record') ?? null;
?>


<div class="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
    <div>
        <h1 class="text-2xl font-extrabold tracking-tight text-slate-900">Maintenance</h1>
        <p class="text-sm text-slate-500">Schedule and track vehicle service and repairs</p>
    </div>

    <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
        
        <form method="GET" action="<?php echo e(route('maintenance.index')); ?>" id="maintenance-search-form" class="flex w-full min-w-0 items-center gap-2 sm:w-72 xl:w-96" onsubmit="return false;">
            <input type="hidden" name="status"   value="<?php echo e(request('status', 'active')); ?>">
            <input type="hidden" name="location" value="<?php echo e(request('location')); ?>">
            <input type="hidden" name="per_page" value="<?php echo e(request('per_page', 10)); ?>">
            <div class="relative w-full">
                <svg xmlns="http://www.w3.org/2000/svg" class="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-600/70" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
                <input
                    type="text"
                    name="search"
                    id="maintenance-search-input"
                    value="<?php echo e(request('search')); ?>"
                    autocomplete="off"
                    placeholder="Search plate, type, shop..."
                    oninput="onMaintenanceSearchInput()"
                    class="w-full rounded-full border border-slate-200 bg-white py-2.5 pl-10 pr-8 text-xs text-slate-800 placeholder-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                <svg id="maintenance-search-spinner" xmlns="http://www.w3.org/2000/svg" class="hidden absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
            </div>
            <a href="<?php echo e(route('maintenance.index', array_filter(['status' => request('status', 'active'), 'location' => request('location'), 'per_page' => request('per_page', 10)]))); ?>"
               id="maintenance-search-clear"
               class="shrink-0 text-xs font-semibold text-slate-500 hover:text-slate-700 <?php echo e(request('search') ? '' : 'hidden'); ?>">Clear</a>
        </form>

        <div class="flex flex-wrap items-center gap-2">
            
            <?php if($isSuperAdmin): ?>
            <div class="relative" id="location-dropdown-wrap">
                <button type="button" onclick="toggleLocationDropdown()"
                    class="inline-flex h-10 items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span class="max-w-[9rem] truncate"><?php echo e($selectedLocation ?: 'All Locations'); ?></span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                </button>
                <div id="location-dropdown" class="absolute left-0 top-full z-30 mt-2 hidden w-64 sm:left-auto sm:right-0 overflow-hidden rounded-xl bg-white p-1.5 shadow-xl ring-1 ring-black/5">
                    <a href="<?php echo e(route('maintenance.index', array_filter(['search' => request('search'), 'status' => request('status','active'), 'per_page' => request('per_page',10)]))); ?>"
                       class="block rounded-lg px-3 py-2 text-xs font-semibold <?php echo e(!$selectedLocation ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700 hover:bg-gray-50'); ?>">All Locations</a>
                    <?php $__currentLoopData = $locationOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('maintenance.index', array_filter(['search' => request('search'), 'status' => request('status','active'), 'location' => $loc, 'per_page' => request('per_page',10)]))); ?>"
                           class="block rounded-lg px-3 py-2 text-xs font-semibold <?php echo e($selectedLocation === $loc ? 'bg-emerald-50 text-emerald-800' : 'text-slate-700 hover:bg-gray-50'); ?>"><?php echo e($loc); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php else: ?>
            <div class="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                <span class="max-w-[9rem] truncate"><?php echo e($selectedLocation ?: 'All Locations'); ?></span>
            </div>
            <?php endif; ?>

            
            <button type="button" onclick="openMaintenanceModal()"
                class="inline-flex h-10 shrink-0 items-center justify-center gap-1.5 rounded-xl bg-[#005a36] px-4 text-xs font-extrabold text-white shadow-sm hover:bg-[#00432a] transition cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                Add Maintenance
            </button>
        </div>
    </div>
</div>


<?php if(session('success')): ?>
    <div id="flash-success" class="mb-3 flex items-center gap-2 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-medium text-green-700">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="mb-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
        <ul class="list-disc list-inside space-y-1">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<div class="mb-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
    <?php $__currentLoopData = [
        ['label'=>'Active',    'value'=>$counts['active'],    'color'=>'text-orange-600', 'icon'=>'alert-triangle'],
        ['label'=>'Scheduled', 'value'=>$counts['scheduled'], 'color'=>'text-sky-600',    'icon'=>'calendar'],
        ['label'=>'Ongoing',   'value'=>$counts['ongoing'],   'color'=>'text-amber-600',  'icon'=>'clock'],
        ['label'=>'Completed', 'value'=>$counts['completed'], 'color'=>'text-emerald-600','icon'=>'check-circle'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="flex items-center gap-3 rounded-xl border border-gray-100 bg-white p-3 shadow-xs">
        <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-50 <?php echo e($stat['color']); ?>">
            <?php if($stat['icon'] === 'alert-triangle'): ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            <?php elseif($stat['icon'] === 'calendar'): ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            <?php elseif($stat['icon'] === 'clock'): ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            <?php else: ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
            <?php endif; ?>
        </div>
        <div>
            <p class="text-xl font-extrabold text-gray-900"><?php echo e($stat['value']); ?></p>
            <p class="text-xs text-gray-500"><?php echo e($stat['label']); ?></p>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="mb-3 flex flex-wrap gap-2">
    <?php $__currentLoopData = $statusFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('maintenance.index', array_filter(['search' => request('search'), 'location' => $selectedLocation, 'status' => $sf, 'per_page' => request('per_page',10)]))); ?>"
       class="rounded-full px-4 py-1.5 text-xs font-bold transition
              <?php echo e($statusFilter === $sf
                 ? 'bg-emerald-600 text-white shadow-sm'
                 : 'border border-gray-200 bg-white text-gray-600 hover:bg-gray-50'); ?>">
        <?php echo e(ucfirst($sf)); ?>

    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php if($records->isEmpty()): ?>
    <div class="flex flex-col items-center justify-center rounded-2xl border border-gray-100 bg-white px-6 py-16 text-center shadow-xs">
        <svg xmlns="http://www.w3.org/2000/svg" class="mb-3 h-10 w-10 text-gray-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
        <p class="font-bold text-gray-700">No maintenance records found</p>
        <p class="mt-1 text-xs text-gray-400">Add scheduled repairs, preventive service, inspections, and other vehicle work here.</p>
    </div>
<?php else: ?>
    <div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-xs">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-100 text-sm">
                <thead class="bg-gray-50 text-xs font-semibold uppercase tracking-wide text-gray-500">
                    <tr>
                        <th class="px-4 py-3 text-left">Vehicle</th>
                        <th class="px-4 py-3 text-left">Maintenance</th>
                        <th class="px-4 py-3 text-left">Schedule</th>
                        <th class="px-4 py-3 text-left">Priority</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-left">Driver</th>
                        <th class="px-4 py-3 text-left">Cost / Vendor</th>
                        <th class="px-4 py-3 text-right"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $ss  = $statusStyles[$record->status]   ?? $statusStyles['cancelled'];
                        $ps  = $priorityStyles[$record->priority] ?? $priorityStyles['normal'];
                        $driver = $record->vehicle?->assignedDriver;
                        $driverName = $driver?->name ?? $record->vehicle?->assigned_driver_name ?? null;
                        $driverInitial = strtoupper(substr($driverName ?? 'D', 0, 1));
                    ?>
                    <tr class="hover:bg-gray-50 transition">
                        
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2.5">
                                <?php if($record->vehicle?->photo_url): ?>
                                    <img src="<?php echo e($record->vehicle->photo_url); ?>" alt="vehicle" class="h-8 w-8 rounded-lg object-cover ring-1 ring-gray-100">
                                <?php else: ?>
                                    <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-400">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 17h4V5H2v12h3"/><path d="M14 17h1a2 2 0 1 0 4 0h1v-5l-3-4h-3"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/></svg>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <p class="font-bold text-gray-900"><?php echo e($record->plate_number); ?></p>
                                    <p class="text-xs text-gray-400"><?php echo e($record->vehicle_label ?? 'Vehicle'); ?></p>
                                </div>
                            </div>
                        </td>

                        
                        <td class="px-4 py-3">
                            <p class="font-semibold text-gray-900"><?php echo e($record->title); ?></p>
                            <p class="text-xs text-gray-400"><?php echo e($record->type); ?></p>
                        </td>

                        
                        <td class="px-4 py-3 text-xs text-gray-500">
                            <p><?php echo e($record->scheduled_date->format('M d, Y')); ?>

                                <?php if($record->scheduled_date_end && $record->scheduled_date_end->ne($record->scheduled_date)): ?>
                                    – <?php echo e($record->scheduled_date_end->format('M d, Y')); ?>

                                <?php endif; ?>
                            </p>
                            <?php if($record->completed_date): ?>
                                <p class="text-emerald-600">Completed: <?php echo e($record->completed_date->format('M d, Y')); ?></p>
                            <?php endif; ?>
                        </td>

                        
                        <td class="px-4 py-3 text-xs font-bold <?php echo e($ps['text']); ?>"><?php echo e($ps['label']); ?></td>

                        
                        <td class="px-4 py-3">
                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold ring-1 <?php echo e($ss['bg']); ?> <?php echo e($ss['text']); ?> <?php echo e($ss['ring']); ?>">
                                <?php echo e($ss['label']); ?>

                            </span>
                        </td>

                        
                        <td class="px-4 py-3">
                            <?php if($driverName): ?>
                                <div class="flex items-center gap-2">
                                    <?php if($driver?->avatar_url): ?>
                                        <img src="<?php echo e($driver->avatar_url); ?>" alt="<?php echo e($driverName); ?>" class="h-6 w-6 rounded-full object-cover">
                                    <?php else: ?>
                                        <div class="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[10px] font-bold text-emerald-700"><?php echo e($driverInitial); ?></div>
                                    <?php endif; ?>
                                    <span class="text-xs font-medium text-gray-700"><?php echo e($driverName); ?></span>
                                </div>
                            <?php else: ?>
                                <span class="text-xs text-gray-300">—</span>
                            <?php endif; ?>
                        </td>

                        
                        <td class="px-4 py-3 text-xs text-gray-500">
                            <?php if($record->cost !== null): ?>
                                <p class="font-semibold">₱<?php echo e(number_format($record->cost, 2)); ?></p>
                            <?php else: ?>
                                <p>—</p>
                            <?php endif; ?>
                            <?php if($record->vendor): ?><p class="text-gray-400"><?php echo e($record->vendor); ?></p><?php endif; ?>
                        </td>

                        
                        <td class="px-4 py-3 text-right">
                            <div class="flex items-center justify-end gap-1">
                                <button type="button"
                                    onclick="openMaintenanceModal(<?php echo e($record->id); ?>)"
                                    class="rounded-md p-1.5 text-blue-500 hover:bg-blue-50 transition" title="Edit">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <?php if($isSuperAdmin): ?>
                                <button type="button"
                                    onclick="openDeleteConfirm(<?php echo e($record->id); ?>, '<?php echo e(addslashes($record->title)); ?>', '<?php echo e(addslashes($record->plate_number)); ?>')"
                                    class="rounded-md p-1.5 text-red-400 hover:bg-red-50 transition" title="Delete">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
        <?php if($records->hasPages()): ?>
        <div class="flex items-center justify-between border-t border-gray-100 px-4 py-3">
            <p class="text-xs text-gray-500">
                Showing <?php echo e($records->firstItem()); ?>–<?php echo e($records->lastItem()); ?> of <?php echo e($records->total()); ?> maintenance records
            </p>
            <div class="flex items-center gap-1">
                
                <select onchange="changePerPage(this.value)"
                    class="mr-2 rounded-lg border border-gray-200 py-1 pl-2 pr-6 text-xs text-gray-600 focus:outline-none focus:ring-1 focus:ring-emerald-400">
                    <?php $__currentLoopData = [10,25,50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pp); ?>" <?php echo e(request('per_page',10) == $pp ? 'selected' : ''); ?>><?php echo e($pp); ?> / page</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <?php if($records->onFirstPage()): ?>
                    <span class="rounded-lg border border-gray-100 px-3 py-1 text-xs text-gray-300">← Prev</span>
                <?php else: ?>
                    <a href="<?php echo e($records->previousPageUrl()); ?>" class="rounded-lg border border-gray-200 px-3 py-1 text-xs text-gray-600 hover:bg-gray-50">← Prev</a>
                <?php endif; ?>
                
                <?php $__currentLoopData = $records->getUrlRange(max(1,$records->currentPage()-2), min($records->lastPage(),$records->currentPage()+2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($url); ?>" class="rounded-lg border px-3 py-1 text-xs font-medium transition
                        <?php echo e($page === $records->currentPage() ? 'border-emerald-500 bg-emerald-600 text-white' : 'border-gray-200 text-gray-600 hover:bg-gray-50'); ?>"><?php echo e($page); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($records->hasMorePages()): ?>
                    <a href="<?php echo e($records->nextPageUrl()); ?>" class="rounded-lg border border-gray-200 px-3 py-1 text-xs text-gray-600 hover:bg-gray-50">Next →</a>
                <?php else: ?>
                    <span class="rounded-lg border border-gray-100 px-3 py-1 text-xs text-gray-300">Next →</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php endif; ?>


<div id="maintenance-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 p-4">
    <div class="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white shadow-2xl">
        
        <div class="sticky top-0 z-10 flex items-center justify-between rounded-t-2xl border-b border-gray-100 bg-white px-5 py-4">
            <h3 id="modal-title" class="text-base font-bold text-gray-900">Add Maintenance</h3>
            <button type="button" onclick="closeMaintenanceModal()" class="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="M6 6l12 12"/></svg>
            </button>
        </div>

        
        <form id="maintenance-form" method="POST" action="<?php echo e(route('maintenance.store')); ?>" class="px-5 py-5 space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" id="form-method" value="POST">
            <input type="hidden" name="source_report_id" id="field-source-report-id" value="">
            <input type="hidden" name="_redirect_search"   value="<?php echo e(request('search')); ?>">
            <input type="hidden" name="_redirect_location" value="<?php echo e($selectedLocation); ?>">
            <input type="hidden" name="_redirect_status"   value="<?php echo e($statusFilter); ?>">
            <input type="hidden" name="_redirect_per_page" value="<?php echo e(request('per_page',10)); ?>">

            
            <div id="source-report-banner" class="hidden rounded-lg border border-emerald-100 bg-emerald-50 px-3 py-2.5 text-xs text-emerald-800">
                <b>Created from driver report:</b> <span id="source-report-banner-text"></span> You can edit every field below before saving.
            </div>

            
            <div>
                <label class="mb-1 block text-xs font-bold text-gray-600">Vehicle <span class="text-red-500">*</span></label>
                <select name="vehicle_id" id="field-vehicle-id" required
                    onchange="onVehicleChange(this.value)"
                    class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                    <option value="">Select vehicle</option>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($v->id); ?>" data-location="<?php echo e($v->location); ?>">
                            <?php echo e($v->plate_number); ?> – <?php echo e($v->brand); ?> <?php echo e($v->model); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div id="active-maintenance-warning" class="hidden rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                <p class="mb-1 flex items-center gap-1 font-bold">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                    Existing active maintenance for this vehicle
                </p>
                <div id="active-maintenance-list" class="space-y-1"></div>
                <p class="mt-1.5 text-amber-700">This is a scheduling reminder only. You may still save another record for the same date(s).</p>
            </div>

            
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Type <span class="text-red-500">*</span></label>
                    <select name="type" id="field-type" required
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                        <?php $__currentLoopData = $maintenanceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mt); ?>"><?php echo e($mt); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Priority <span class="text-red-500">*</span></label>
                    <select name="priority" id="field-priority" required
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                        <option value="normal">Normal</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>
            </div>

            
            <div>
                <label class="mb-1 block text-xs font-bold text-gray-600">Title <span class="text-red-500">*</span></label>
                <input type="text" name="title" id="field-title" required placeholder="e.g. Replace worn tires"
                    class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
            </div>

            
            <div>
                <label class="mb-1 block text-xs font-bold text-gray-600">Description</label>
                <textarea name="description" id="field-description" rows="3" placeholder="Work needed, parts, observations..."
                    class="w-full resize-y rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400"></textarea>
            </div>

            
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Start Date <span class="text-red-500">*</span></label>
                    <input type="date" name="scheduled_date" id="field-scheduled-date" required
                        onchange="onDateChange()"
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">End Date</label>
                    <input type="date" name="scheduled_date_end" id="field-scheduled-date-end"
                        onchange="onDateChange()"
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                </div>
            </div>

            
            <div id="schedule-calendar-wrap" class="hidden rounded-xl border border-blue-100 bg-blue-50/50 p-3">
                <div class="mb-2 flex items-center justify-between">
                    <button type="button" onclick="calendarPrev()" class="flex h-7 w-7 items-center justify-center rounded-md border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 text-base">‹</button>
                    <div class="text-center">
                        <p class="text-xs font-extrabold text-slate-700">Maintenance Schedule</p>
                        <p id="calendar-month-label" class="text-[11px] text-gray-400"></p>
                    </div>
                    <button type="button" onclick="calendarNext()" class="flex h-7 w-7 items-center justify-center rounded-md border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 text-base">›</button>
                </div>
                <div id="calendar-grid" class="grid grid-cols-7 gap-0.5 text-center text-[10px]"></div>
                <div id="calendar-overlap-warning" class="hidden mt-2 rounded-lg bg-red-50 px-3 py-2 text-[11px] font-bold text-red-700">
                    Your selected date(s) overlap existing maintenance. You may still continue if both jobs are intended.
                </div>
                <div class="mt-2 flex flex-wrap gap-3 text-[10.5px] text-gray-500">
                    <span class="flex items-center gap-1"><i class="inline-block h-2.5 w-2.5 rounded-sm bg-amber-400"></i> Existing maintenance</span>
                    <span class="flex items-center gap-1"><i class="inline-block h-2.5 w-2.5 rounded-sm border-2 border-teal-500 bg-white"></i> Selected date(s)</span>
                </div>
            </div>

            
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Status <span class="text-red-500">*</span></label>
                    <select name="status" id="field-status" required
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                        <option value="scheduled">Scheduled</option>
                        <option value="ongoing">Ongoing</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Completed Date</label>
                    <input type="date" name="completed_date" id="field-completed-date"
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                </div>
            </div>

            
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Odometer</label>
                    <input type="number" name="odometer" id="field-odometer" min="0" placeholder="km"
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-gray-600">Cost (₱)</label>
                    <input type="number" name="cost" id="field-cost" min="0" step="0.01" placeholder="0.00"
                        class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                </div>
            </div>

            
            <div>
                <label class="mb-1 block text-xs font-bold text-gray-600">Vendor / Shop</label>
                <input type="text" name="vendor" id="field-vendor" placeholder="Shop name or supplier"
                    class="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
            </div>

            
            <div>
                <label class="mb-1 block text-xs font-bold text-gray-600">Notes</label>
                <textarea name="notes" id="field-notes" rows="2" placeholder="Admin notes"
                    class="w-full resize-y rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400"></textarea>
            </div>

            <button type="submit" id="modal-submit-btn"
                class="w-full rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 py-2.5 text-sm font-extrabold text-white shadow-sm hover:from-emerald-700 hover:to-emerald-800 transition">
                Add Maintenance
            </button>
        </form>
    </div>
</div>


<div id="delete-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 p-4">
    <div class="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
        <div class="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-red-100 text-red-600">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
        </div>
        <h3 class="mb-1 text-base font-bold text-gray-900">Delete Maintenance Record?</h3>
        <p id="delete-modal-message" class="mb-5 text-sm text-gray-500"></p>
        <div class="flex gap-2">
            <button type="button" onclick="closeDeleteConfirm()"
                class="flex-1 rounded-xl border border-gray-200 py-2 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition">Cancel</button>
            <form id="delete-form" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit"
                    class="w-full rounded-xl bg-red-600 px-6 py-2 text-sm font-bold text-white hover:bg-red-700 transition">Delete</button>
            </form>
        </div>
    </div>
</div>


<?php
    // Built here (instead of inline inside @json) because Blade's directive
    // parser only tracks round-bracket balance, not square brackets — a
    // multi-line array literal with 3+ keys directly inside @json(...) gets
    // silently truncated at compile time and breaks the view.
    $maintenanceRecordsForJs = $records->map(fn($r) => [
        'id'                 => $r->id,
        'vehicle_id'         => $r->vehicle_id,
        'plate_number'       => $r->plate_number,
        'vehicle_label'      => $r->vehicle_label,
        'type'               => $r->type,
        'title'              => $r->title,
        'description'        => $r->description,
        'status'             => $r->status,
        'priority'           => $r->priority,
        'scheduled_date'     => $r->scheduled_date?->format('Y-m-d'),
        'scheduled_date_end' => $r->scheduled_date_end?->format('Y-m-d'),
        'completed_date'     => $r->completed_date?->format('Y-m-d'),
        'odometer'           => $r->odometer,
        'cost'               => $r->cost,
        'vendor'             => $r->vendor,
        'notes'              => $r->notes,
    ])->values();
?>
<script>
// ── Record data from PHP → JS ──────────────────────────────────────────────
const maintenanceRecords = <?php echo json_encode($maintenanceRecordsForJs, 15, 512) ?>;
const sourceReportFromDriver = <?php echo json_encode($sourceReport, 15, 512) ?>;

document.addEventListener('DOMContentLoaded', function () {
    if (sourceReportFromDriver) {
        openMaintenanceModalFromReport(sourceReportFromDriver);
    }
});


// All active (scheduled/ongoing) records across all pages for calendar conflict detection
// We only have the current page here, but that's enough for a scheduling hint.
const allActiveRecords = maintenanceRecords.filter(r => r.status === 'scheduled' || r.status === 'ongoing');

// ── Modal open/close ───────────────────────────────────────────────────────
let currentEditId = null;

function openMaintenanceModal(id = null) {
    currentEditId = id;
    const modal   = document.getElementById('maintenance-modal');
    const form    = document.getElementById('maintenance-form');
    const title   = document.getElementById('modal-title');
    const btn     = document.getElementById('modal-submit-btn');
    const method  = document.getElementById('form-method');

    resetForm();

    if (id) {
        const rec = maintenanceRecords.find(r => r.id === id);
        if (!rec) return;
        title.textContent  = 'Edit Maintenance';
        btn.textContent    = 'Save Changes';
        method.value       = 'PUT';
        form.action        = `/maintenance/${id}`;

        setField('vehicle_id',         rec.vehicle_id);
        setField('type',               rec.type);
        setField('priority',           rec.priority);
        setField('title',              rec.title);
        setField('description',        rec.description ?? '');
        setField('status',             rec.status);
        setField('scheduled_date',     rec.scheduled_date ?? '');
        setField('scheduled_date_end', rec.scheduled_date_end ?? '');
        setField('completed_date',     rec.completed_date ?? '');
        setField('odometer',           rec.odometer ?? '');
        setField('cost',               rec.cost ?? '');
        setField('vendor',             rec.vendor ?? '');
        setField('notes',              rec.notes ?? '');

        onVehicleChange(rec.vehicle_id, id);
        updateCalendar();
    } else {
        title.textContent = 'Add Maintenance';
        btn.textContent   = 'Add Maintenance';
        method.value      = 'POST';
        form.action       = '<?php echo e(route("maintenance.store")); ?>';
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeMaintenanceModal() {
    document.getElementById('maintenance-modal').classList.add('hidden');
    document.getElementById('maintenance-modal').classList.remove('flex');
    currentEditId = null;
    if (window.location.search.includes('reportId')) {
        const url = new URL(window.location.href);
        url.searchParams.delete('reportId');
        window.history.replaceState({}, '', url);
    }
}

function resetForm() {
    const fields = ['vehicle_id','type','priority','title','description','status','scheduled_date','scheduled_date_end','completed_date','odometer','cost','vendor','notes'];
    fields.forEach(f => setField(f, f === 'type' ? 'Preventive' : f === 'priority' ? 'normal' : f === 'status' ? 'scheduled' : ''));
    document.getElementById('field-source-report-id').value = '';
    document.getElementById('source-report-banner').classList.add('hidden');
    document.getElementById('active-maintenance-warning').classList.add('hidden');
    document.getElementById('schedule-calendar-wrap').classList.add('hidden');
}

// ── Prefill from a driver's Vehicle Report (?reportId=... on this page) ────
function openMaintenanceModalFromReport(report) {
    currentEditId = null;
    const modal  = document.getElementById('maintenance-modal');
    const form   = document.getElementById('maintenance-form');
    const title  = document.getElementById('modal-title');
    const btn    = document.getElementById('modal-submit-btn');
    const method = document.getElementById('form-method');

    resetForm();

    title.textContent = 'Add Maintenance';
    btn.textContent    = 'Add Maintenance';
    method.value       = 'POST';
    form.action        = '<?php echo e(route("maintenance.store")); ?>';

    const typeMap = { Tire: 'Tire', Battery: 'Battery', Other: 'Other' };

    setField('vehicle_id',  report.vehicle_id);
    setField('type',        typeMap[report.issue_type] || 'Repair');
    setField('priority',    report.priority);
    setField('title',       `Driver report: ${report.issue_type} issue`);
    setField('description', report.description);
    setField('notes',       `Reported by ${report.driver_name}.`);
    document.getElementById('field-source-report-id').value = report.id;

    const banner = document.getElementById('source-report-banner');
    document.getElementById('source-report-banner-text').textContent =
        `${report.driver_name} reported a ${report.issue_type.toLowerCase()} issue.`;
    banner.classList.remove('hidden');

    onVehicleChange(report.vehicle_id);

    modal.classList.remove('hidden');
    modal.classList.add('flex');
}


function setField(name, value) {
    const el = document.getElementById(`field-${name.replace(/_/g,'-')}`);
    if (el) el.value = value ?? '';
}

// ── Vehicle change: show active maintenance warning ───────────────────────
function onVehicleChange(vehicleId, excludeId = null) {
    excludeId = excludeId ?? currentEditId;
    const active = allActiveRecords.filter(r => r.vehicle_id == vehicleId && r.id != excludeId);
    const wrap   = document.getElementById('active-maintenance-warning');
    const list   = document.getElementById('active-maintenance-list');

    if (active.length === 0) {
        wrap.classList.add('hidden');
        return;
    }

    list.innerHTML = active.map(r => {
        const start = r.scheduled_date ? formatDate(r.scheduled_date) : '—';
        const end   = r.scheduled_date_end && r.scheduled_date_end !== r.scheduled_date ? ` – ${formatDate(r.scheduled_date_end)}` : '';
        return `<div class="rounded-md bg-white border border-amber-100 px-2 py-1"><b>${escHtml(r.title)}</b> · ${start}${end} · ${capitalize(r.status)}</div>`;
    }).join('');

    wrap.classList.remove('hidden');
    updateCalendar();
}

// ── Mini scheduling calendar ───────────────────────────────────────────────
let calYear, calMonth;

function onDateChange() { updateCalendar(); }

function updateCalendar() {
    const vehicleId  = document.getElementById('field-vehicle-id')?.value;
    const startDate  = document.getElementById('field-scheduled-date')?.value;
    const endDate    = document.getElementById('field-scheduled-date_end')?.value
                    || document.getElementById('field-scheduled-date-end')?.value;
    const wrap       = document.getElementById('schedule-calendar-wrap');

    if (!vehicleId || !startDate) { wrap.classList.add('hidden'); return; }
    wrap.classList.remove('hidden');

    const [sy, sm] = startDate.split('-').map(Number);
    if (!calYear) { calYear = sy; calMonth = sm - 1; }

    renderCalendar(vehicleId, startDate, endDate || startDate);
}

function renderCalendar(vehicleId, startDate, endDate) {
    if (!calYear && !calMonth && calMonth !== 0) return;

    const label  = document.getElementById('calendar-month-label');
    const grid   = document.getElementById('calendar-grid');
    const overlap = document.getElementById('calendar-overlap-warning');

    const firstOfMonth  = new Date(calYear, calMonth, 1);
    const daysInMonth   = new Date(calYear, calMonth + 1, 0).getDate();
    label.textContent   = firstOfMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

    // Build existing maintenance days for this vehicle
    const existingDays = new Map();
    const excludeId = currentEditId;
    allActiveRecords
        .filter(r => r.vehicle_id == vehicleId && r.id != excludeId)
        .forEach(r => {
            const s = new Date(`${r.scheduled_date}T00:00:00`);
            const e = new Date(`${r.scheduled_date_end || r.scheduled_date}T00:00:00`);
            for (const d = new Date(s); d <= e; d.setDate(d.getDate() + 1)) {
                const k = localKey(d);
                existingDays.set(k, [...(existingDays.get(k) || []), r.title]);
            }
        });

    // Build selected days
    const selectedDays = new Set();
    if (startDate) {
        const s = new Date(`${startDate}T00:00:00`);
        const e = new Date(`${endDate || startDate}T00:00:00`);
        if (e >= s) for (const d = new Date(s); d <= e; d.setDate(d.getDate() + 1)) selectedDays.add(localKey(d));
    }

    const hasOverlap = [...selectedDays].some(k => existingDays.has(k));
    overlap.classList.toggle('hidden', !hasOverlap);

    const dayHeaders = ['S','M','T','W','T','F','S'].map(d => `<div class="py-0.5 text-[9px] font-bold text-gray-400">${d}</div>`).join('');
    const blanks = Array(firstOfMonth.getDay()).fill('<div></div>').join('');
    const cells  = Array.from({ length: daysInMonth }, (_, i) => {
        const day = i + 1;
        const k   = `${calYear}-${String(calMonth+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
        const ex  = existingDays.get(k);
        const sel = selectedDays.has(k);
        const title = ex ? `Existing: ${ex.join(', ')}` : '';
        let cls = 'flex items-center justify-center rounded text-[11px] h-6 ';
        if (ex)       cls += 'bg-amber-400 text-white font-bold ';
        else if (sel) cls += 'bg-white font-bold text-slate-700 ring-2 ring-teal-500 ';
        else          cls += 'bg-white text-slate-500 ring-1 ring-gray-100 ';
        return `<div class="${cls}" title="${escHtml(title)}">${day}</div>`;
    }).join('');

    grid.innerHTML = dayHeaders + blanks + cells;
}

function calendarPrev() {
    const d = new Date(calYear, calMonth - 1, 1);
    calYear = d.getFullYear(); calMonth = d.getMonth();
    const vId = document.getElementById('field-vehicle-id')?.value;
    const s   = document.getElementById('field-scheduled-date')?.value;
    const e   = document.getElementById('field-scheduled-date-end')?.value;
    if (vId) renderCalendar(vId, s, e || s);
}
function calendarNext() {
    const d = new Date(calYear, calMonth + 1, 1);
    calYear = d.getFullYear(); calMonth = d.getMonth();
    const vId = document.getElementById('field-vehicle-id')?.value;
    const s   = document.getElementById('field-scheduled-date')?.value;
    const e   = document.getElementById('field-scheduled-date-end')?.value;
    if (vId) renderCalendar(vId, s, e || s);
}

// ── Delete confirm ─────────────────────────────────────────────────────────
function openDeleteConfirm(id, title, plate) {
    document.getElementById('delete-modal-message').innerHTML =
        `Delete <strong>${escHtml(title)}</strong> for <strong>${escHtml(plate)}</strong>?`;
    document.getElementById('delete-form').action = `/maintenance/${id}`;
    document.getElementById('delete-modal').classList.remove('hidden');
    document.getElementById('delete-modal').classList.add('flex');
}
function closeDeleteConfirm() {
    document.getElementById('delete-modal').classList.add('hidden');
    document.getElementById('delete-modal').classList.remove('flex');
}

// ── Location dropdown ──────────────────────────────────────────────────────
function toggleLocationDropdown() {
    document.getElementById('location-dropdown')?.classList.toggle('hidden');
}
document.addEventListener('click', function(e) {
    if (!document.getElementById('location-dropdown-wrap')?.contains(e.target)) {
        document.getElementById('location-dropdown')?.classList.add('hidden');
    }
});

// ── Search with debounce ───────────────────────────────────────────────────
let searchTimer;
function onMaintenanceSearchInput() {
    clearTimeout(searchTimer);
    document.getElementById('maintenance-search-spinner')?.classList.remove('hidden');
    document.getElementById('maintenance-search-clear')?.classList.add('hidden');
    searchTimer = setTimeout(() => {
        document.getElementById('maintenance-search-form')?.submit();
    }, 420);
}

// ── Per-page change ────────────────────────────────────────────────────────
function changePerPage(val) {
    const url = new URL(window.location.href);
    url.searchParams.set('per_page', val);
    url.searchParams.set('page', 1);
    window.location.href = url.toString();
}

// ── Helpers ───────────────────────────────────────────────────────────────
function localKey(date) {
    return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
}
function formatDate(str) {
    if (!str) return '—';
    const [y,m,d] = str.split('-');
    return new Date(y,m-1,d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
}
function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }
function escHtml(s) {
    return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Auto-dismiss flash ────────────────────────────────────────────────────
const flash = document.getElementById('flash-success');
if (flash) setTimeout(() => flash.style.display = 'none', 4000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Maintenance\Providers/../Views/index.blade.php ENDPATH**/ ?>