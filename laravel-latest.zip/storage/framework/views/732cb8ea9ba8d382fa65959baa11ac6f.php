<?php
    // data-category carries the vehicle type slug so the chips can filter rows/cards.
    $vehicleCategory = static fn (?string $type): string => \Modules\Vehicle\Models\VehicleType::resolve($type)?->slug ?? 'car';
?>

<?php if($vehicles->isEmpty()): ?>
    <div class="rounded-xl border border-dashed border-gray-300 bg-white px-6 py-14 text-center">
        <p class="text-sm font-medium text-gray-900">No vehicles found</p>
        <p class="mt-1 text-sm text-gray-500">
            <?php if(request('search')): ?>
                No results match "<?php echo e(request('search')); ?>".
            <?php else: ?>
                Get started by registering your first vehicle.
            <?php endif; ?>
        </p>
    </div>
<?php else: ?>
    
    <div id="vehicle-view-list" class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-100 text-left text-xs">
                <thead class="bg-gray-50 font-bold uppercase tracking-wider text-slate-400">
                    <tr>
                        <th class="px-4 py-3 font-semibold">Plate</th>
                        <th class="px-4 py-3 font-semibold">Brand / Model</th>
                        <th class="px-4 py-3 font-semibold">Assigned Driver</th>
                        <th class="px-4 py-3 font-semibold">Year</th>
                        <th class="px-4 py-3 font-semibold">Color</th>
                        <th class="px-4 py-3 font-semibold">Odometer</th>
                        <th class="px-4 py-3 font-semibold">Type</th>
                        <th class="px-4 py-3 font-semibold">Fuel</th>
                        <th class="px-4 py-3 font-semibold">Location</th>
                        <th class="px-4 py-3 text-right font-semibold"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 text-slate-700">
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="vehicle-row hover:bg-slate-50/70 transition" data-category="<?php echo e($vehicleCategory($vehicle->vehicle_type)); ?>">
                            
                            <td class="whitespace-nowrap px-4 py-3 font-bold text-slate-900">
                                <div class="flex items-center gap-3">
                                    <?php if($vehicle->photo_url): ?>
                                        <img src="<?php echo e($vehicle->photo_url); ?>" alt="<?php echo e($vehicle->plate_number); ?>" class="h-9 w-12 shrink-0 rounded-lg object-cover border border-slate-100">
                                    <?php else: ?>
                                        <div class="flex h-9 w-12 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-400 border border-slate-200/60">
                                            <?php echo $__env->make('vehicle::partials.vehicle-type-icon', ['type' => $vehicle->vehicle_type, 'class' => 'h-5 w-5', 'stroke' => '1.75'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    <?php endif; ?>
                                    <span><?php echo e($vehicle->plate_number); ?></span>
                                </div>
                            </td>

                            
                            <td class="whitespace-nowrap px-4 py-3 font-semibold text-slate-800">
                                <?php echo e($vehicle->brand); ?> <?php echo e($vehicle->model); ?>

                            </td>

                            
                            <td class="whitespace-nowrap px-4 py-3">
                                <?php if($vehicle->assignedDriver): ?>
                                    <div class="flex items-center gap-2.5">
                                        <div class="relative flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#005a36] text-white text-xs font-bold">
                                            <?php if($vehicle->assignedDriver->avatar_url): ?>
                                                <img src="<?php echo e($vehicle->assignedDriver->avatar_url); ?>" alt="<?php echo e($vehicle->assignedDriver->name); ?>" class="h-full w-full object-cover">
                                            <?php else: ?>
                                                <span><?php echo e(strtoupper(substr($vehicle->assignedDriver->name, 0, 1))); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="min-w-0 leading-tight">
                                            <p class="truncate text-xs font-bold text-slate-900"><?php echo e($vehicle->assignedDriver->name); ?></p>
                                            <p class="truncate text-[10px] text-slate-400"><?php echo e($vehicle->assignedDriver->phone_number ?: '—'); ?></p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>

                            <td class="whitespace-nowrap px-4 py-3 text-slate-500 font-medium"><?php echo e($vehicle->year); ?></td>
                            <td class="whitespace-nowrap px-4 py-3 text-slate-500 font-medium"><?php echo e($vehicle->color); ?></td>
                            <td class="whitespace-nowrap px-4 py-3 text-slate-500 font-medium"><?php echo e(number_format($vehicle->odometer)); ?> km</td>
                            <td class="whitespace-nowrap px-4 py-3 text-slate-500 font-medium"><?php echo e($vehicle->vehicle_type ?: '—'); ?></td>
                            <td class="whitespace-nowrap px-4 py-3 text-slate-500 font-medium"><?php echo e($vehicle->fuel_type ?: '—'); ?></td>
                            <td class="whitespace-nowrap px-4 py-3 text-slate-500 font-medium"><?php echo e($vehicle->location ?: '—'); ?></td>

                            <td class="whitespace-nowrap px-4 py-3 text-right">
                                <?php if (isset($component)) { $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'vehicle::components.row-actions','data' => ['vehicle' => $vehicle]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vehicle::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['vehicle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicle)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $attributes = $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $component = $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div id="vehicle-view-grid" class="hidden grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="vehicle-card overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm" data-category="<?php echo e($vehicleCategory($vehicle->vehicle_type)); ?>">
                
                <div class="relative">
                    <?php if($vehicle->photo_url): ?>
                        <img src="<?php echo e($vehicle->photo_url); ?>" alt="<?php echo e($vehicle->plate_number); ?>" class="h-40 w-full object-cover">
                    <?php else: ?>
                        <div class="flex h-40 w-full items-center justify-center bg-slate-100 text-slate-400">
                            <?php echo $__env->make('vehicle::partials.vehicle-type-icon', ['type' => $vehicle->vehicle_type, 'class' => 'h-10 w-10', 'stroke' => '1.5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <span class="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-emerald-50/95 px-2.5 py-1 text-[11px] font-bold text-emerald-700 shadow-sm ring-1 ring-emerald-100">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M10 17h4V5H2v12h3"/>
                            <path d="M14 17h1a2 2 0 1 0 4 0h1v-5l-3-4h-3"/>
                            <circle cx="7" cy="17" r="2"/>
                            <circle cx="17" cy="17" r="2"/>
                        </svg>
                        Active
                    </span>

                    
                    <div class="absolute right-2 top-2 rounded-lg bg-white/95 shadow-sm">
                        <?php if (isset($component)) { $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'vehicle::components.row-actions','data' => ['vehicle' => $vehicle,'menu' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vehicle::row-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['vehicle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicle),'menu' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $attributes = $__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__attributesOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5)): ?>
<?php $component = $__componentOriginal962dffddd2ec0e7924c9d612735fd2d5; ?>
<?php unset($__componentOriginal962dffddd2ec0e7924c9d612735fd2d5); ?>
<?php endif; ?>
                    </div>
                </div>

                
                <div class="space-y-2 p-4">
                    <p class="flex items-center gap-1.5 text-[15px] font-bold text-slate-900">
                        <?php echo $__env->make('vehicle::partials.vehicle-type-icon', ['type' => $vehicle->vehicle_type, 'class' => 'h-4 w-4 shrink-0 text-[#005a36]', 'stroke' => '2'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <span class="truncate"><?php echo e($vehicle->brand); ?> <?php echo e($vehicle->model); ?> <?php echo e($vehicle->year); ?></span>
                    </p>

                    <div class="space-y-1.5 text-[13px] text-slate-500">
                        <div class="flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="2" y="7" width="20" height="10" rx="2"/><path d="M6 7V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2"/>
                            </svg>
                            <span class="truncate"><?php echo e($vehicle->plate_number); ?></span>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M9 3H5a2 2 0 0 0-2 2v4M9 3v18M9 3h10a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H9"/>
                            </svg>
                            <span class="truncate"><?php echo e($vehicle->chassis_number ?: '—'); ?></span>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/>
                            </svg>
                            <span class="truncate"><?php echo e($vehicle->engine_number ?: '—'); ?></span>
                        </div>
                    </div>

                    <div class="flex items-center gap-4 border-t border-slate-100 pt-2 text-[13px] text-slate-600">
                        <span class="flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 17h14M5 17a2 2 0 1 0 4 0m6 0a2 2 0 1 0 4 0M5 17V9l2-5h10l2 5v8"/>
                            </svg>
                            <?php echo e($vehicle->vehicle_type ?: '—'); ?>

                        </span>
                        <span class="flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 22V4a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v18"/><path d="M14 13h4a2 2 0 0 1 2 2v4a2 2 0 0 0 2 2h0"/>
                            </svg>
                            <?php echo e($vehicle->fuel_type ?: '—'); ?>

                        </span>
                    </div>

                    <div class="flex items-start gap-1.5 pt-0.5 text-[13px] font-medium text-emerald-700">
                        <svg xmlns="http://www.w3.org/2000/svg" class="mt-0.5 h-3.5 w-3.5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>
                        </svg>
                        <span class="truncate"><?php echo e($vehicle->location ?: 'No location assigned'); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div id="vehicle-empty-filter-state" class="hidden rounded-xl border border-dashed border-gray-300 bg-white px-6 py-14 text-center">
        <p class="text-sm font-medium text-gray-900">No vehicles in this category on this page</p>
        <p class="mt-1 text-sm text-gray-500">Try another category, or clear the filter.</p>
    </div>

    
    <div class="mt-4 flex flex-col gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3 shadow-sm sm:flex-row sm:items-center sm:justify-between">
        <div class="flex flex-wrap items-center gap-4 text-xs text-slate-500 font-medium">
            <div>
                Showing <span class="font-bold text-slate-700"><?php echo e($vehicles->firstItem() ?? 0); ?></span> to <span class="font-bold text-slate-700"><?php echo e($vehicles->lastItem() ?? 0); ?></span> of <span class="font-bold text-slate-700"><?php echo e($vehicles->total()); ?></span> vehicles
            </div>

            <div class="flex items-center gap-2">
                <span>Rows per page:</span>
                <select id="vehicle-per-page-select" onchange="changeVehiclePerPage(this.value)" class="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-semibold text-slate-700 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer">
                    <?php $__currentLoopData = [10, 15, 20, 25, 50, 75, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="flex items-center gap-1">
            <button type="button" onclick="goToVehiclePage(1)" <?php if($vehicles->onFirstPage()): echo 'disabled'; endif; ?> class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &laquo;
            </button>
            <button type="button" onclick="goToVehiclePage(<?php echo e(max(1, $vehicles->currentPage() - 1)); ?>)" <?php if($vehicles->onFirstPage()): echo 'disabled'; endif; ?> class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &lt;
            </button>

            <?php $__currentLoopData = $vehicles->getUrlRange(max(1, $vehicles->currentPage() - 1), min($vehicles->lastPage(), $vehicles->currentPage() + 1)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" onclick="goToVehiclePage(<?php echo e($page); ?>)" class="inline-flex h-8 w-8 items-center justify-center rounded-lg border text-xs font-bold transition <?php echo e($page == $vehicles->currentPage() ? 'bg-[#005a36] text-white border-[#005a36]' : 'border-slate-200 text-slate-700 hover:bg-slate-50'); ?>">
                    <?php echo e($page); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="button" onclick="goToVehiclePage(<?php echo e(min($vehicles->lastPage(), $vehicles->currentPage() + 1)); ?>)" <?php if(!$vehicles->hasMorePages()): echo 'disabled'; endif; ?> class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &gt;
            </button>
            <button type="button" onclick="goToVehiclePage(<?php echo e($vehicles->lastPage()); ?>)" <?php if(!$vehicles->hasMorePages()): echo 'disabled'; endif; ?> class="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &raquo;
            </button>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Vehicle\Providers/../Views/partials/vehicle-results.blade.php ENDPATH**/ ?>