<?php if($drivers->isEmpty()): ?>
    <div class="rounded-xl border border-dashed border-gray-300 bg-white px-6 py-14 text-center">
        <p class="text-sm font-bold text-gray-900">No drivers found</p>
        <p class="mt-1 text-sm text-gray-500">
            <?php if(request('search')): ?>
                No results match "<?php echo e(request('search')); ?>".
            <?php else: ?>
                Get started by registering your first driver.
            <?php endif; ?>
        </p>
    </div>
<?php else: ?>
    
    <div id="driver-view-list" class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Name</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Email</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Phone</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">Assigned Location</th>
                        <th class="whitespace-nowrap px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-slate-500">License Expiry</th>
                        <th class="whitespace-nowrap px-4 py-3 text-right text-xs font-bold uppercase tracking-wide text-slate-500">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $initial = Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($driver->name, 0, 1));
                        ?>
                        <tr class="hover:bg-gray-50/70">
                            <td class="whitespace-nowrap px-4 py-3.5">
                                <div class="flex items-center gap-3">
                                    <?php if($driver->avatar_url): ?>
                                        <img src="<?php echo e($driver->avatar_url); ?>" alt="<?php echo e($driver->name); ?>" class="h-9 w-9 shrink-0 rounded-full object-cover ring-1 ring-gray-200">
                                    <?php else: ?>
                                        <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-900 text-xs font-bold text-white">
                                            <?php echo e($initial); ?>

                                        </div>
                                    <?php endif; ?>
                                    <span class="text-sm font-semibold text-gray-900"><?php echo e($driver->name); ?></span>
                                </div>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3.5 text-sm text-slate-500"><?php echo e($driver->email); ?></td>
                            <td class="whitespace-nowrap px-4 py-3.5 text-sm text-slate-500"><?php echo e($driver->phone_number ?: '—'); ?></td>
                            <td class="whitespace-nowrap px-4 py-3.5 text-sm font-semibold text-emerald-800"><?php echo e($driver->location ?: '—'); ?></td>
                            <td class="whitespace-nowrap px-4 py-3.5 text-sm">
                                <?php
                                    $expDate = $driver->license_expiration_date;
                                    $daysLeft = $expDate ? now()->startOfDay()->diffInDays($expDate->startOfDay(), false) : null;
                                ?>
                                <?php if(!$expDate): ?>
                                    <span class="text-slate-400">—</span>
                                <?php elseif($daysLeft < 0): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-[11px] font-bold text-red-700">
                                        <span class="h-1.5 w-1.5 rounded-full bg-red-600 animate-pulse"></span>
                                        EXPIRED · <?php echo e($expDate->format('M d, Y')); ?>

                                    </span>
                                <?php elseif($daysLeft <= 7): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-[11px] font-bold text-red-600 ring-1 ring-red-200">
                                        <span class="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse"></span>
                                        <?php echo e($expDate->format('M d, Y')); ?> · <?php echo e($daysLeft); ?>d left
                                    </span>
                                <?php elseif($daysLeft <= 30): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-bold text-amber-700 ring-1 ring-amber-200">
                                        <span class="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                                        <?php echo e($expDate->format('M d, Y')); ?> · <?php echo e($daysLeft); ?>d left
                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-600 font-medium"><?php echo e($expDate->format('M d, Y')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3.5 text-right">
                                <div class="flex items-center justify-end gap-2">
                                    <button
                                        type="button"
                                        onclick="openEditDriverModal(this)"
                                        data-name="<?php echo e($driver->name); ?>"
                                        data-email="<?php echo e($driver->email); ?>"
                                        data-avatar="<?php echo e($driver->avatar_url); ?>"
                                        data-address="<?php echo e($driver->address); ?>"
                                        data-birth-date="<?php echo e(optional($driver->birth_date)->format('Y-m-d')); ?>"
                                        data-license-number="<?php echo e($driver->license_number); ?>"
                                        data-license-expiration="<?php echo e(optional($driver->license_expiration_date)->format('Y-m-d')); ?>"
                                        data-license-front="<?php echo e($driver->license_front_url); ?>"
                                        data-license-back="<?php echo e($driver->license_back_url); ?>"
                                        data-phone-number="<?php echo e($driver->phone_number); ?>"
                                        data-location="<?php echo e($driver->location); ?>"
                                        data-update-url="<?php echo e(route('driver.update', $driver)); ?>"
                                        title="Edit"
                                        class="text-blue-500 hover:text-blue-700 p-1"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                            <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5Z"/>
                                        </svg>
                                    </button>
                                    <button
                                        type="button"
                                        onclick="openDeleteDriverModal(this)"
                                        data-name="<?php echo e($driver->name); ?>"
                                        data-delete-url="<?php echo e(route('driver.destroy', $driver)); ?>"
                                        title="Delete"
                                        class="text-red-500 hover:text-red-700 p-1"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M3 6h18"/>
                                            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
                                        </svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div id="driver-view-grid" class="hidden grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $initial = Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($driver->name, 0, 1));
                $assignedVehicles = $driver->assignedVehicles;
            ?>
            <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm flex flex-col justify-between">
                <div>
                    
                    <div class="relative p-3">
                        <?php if($driver->avatar_url): ?>
                            <img src="<?php echo e($driver->avatar_url); ?>" alt="<?php echo e($driver->name); ?>" class="h-48 w-full rounded-xl object-cover border border-gray-200">
                        <?php else: ?>
                            <div class="flex h-48 w-full items-center justify-center rounded-xl bg-slate-800 text-5xl font-bold text-white border border-gray-200">
                                <?php echo e($initial); ?>

                            </div>
                        <?php endif; ?>

                        
                        <div class="absolute top-5 right-5 flex items-center gap-1 rounded-lg bg-white/80 p-1 backdrop-blur-md shadow-xs">
                            <button
                                type="button"
                                onclick="openEditDriverModal(this)"
                                data-name="<?php echo e($driver->name); ?>"
                                data-email="<?php echo e($driver->email); ?>"
                                data-avatar="<?php echo e($driver->avatar_url); ?>"
                                data-initial="<?php echo e($initial); ?>"
                                data-address="<?php echo e($driver->address); ?>"
                                data-birth-date="<?php echo e(optional($driver->birth_date)->format('Y-m-d')); ?>"
                                data-license-number="<?php echo e($driver->license_number); ?>"
                                data-license-expiration="<?php echo e(optional($driver->license_expiration_date)->format('Y-m-d')); ?>"
                                data-phone-number="<?php echo e($driver->phone_number); ?>"
                                data-location="<?php echo e($driver->location); ?>"
                                data-update-url="<?php echo e(route('driver.update', $driver)); ?>"
                                title="Edit driver"
                                class="inline-flex h-7 w-7 items-center justify-center rounded-md bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white transition shadow-xs"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5Z"/>
                                </svg>
                            </button>
                            <button
                                type="button"
                                onclick="openDeleteDriverModal(this)"
                                data-name="<?php echo e($driver->name); ?>"
                                data-delete-url="<?php echo e(route('driver.destroy', $driver)); ?>"
                                title="Delete driver"
                                class="inline-flex h-7 w-7 items-center justify-center rounded-md bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition shadow-xs"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M3 6h18"/>
                                    <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    
                    <div class="px-4 pb-3 space-y-1.5">
                        <div class="flex items-center justify-between gap-2">
                            <p class="truncate text-base font-bold text-slate-900"><?php echo e($driver->name); ?></p>
                            <span class="inline-flex items-center gap-1 shrink-0 rounded-full bg-emerald-100/70 px-2 py-0.5 text-[10px] font-semibold text-emerald-800">
                                <span class="h-1.5 w-1.5 rounded-full bg-emerald-600"></span>
                                Active
                            </span>
                        </div>

                        
                        <div class="space-y-1 text-xs text-slate-500 pt-0.5">
                            <div class="flex items-center gap-1.5">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                                <span class="truncate"><?php echo e($driver->email); ?></span>
                            </div>
                            <div class="flex items-center gap-1.5">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                                <span><?php echo e($driver->phone_number ?: '—'); ?></span>
                            </div>
                            <div class="flex items-center gap-1.5 text-emerald-800 font-medium">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 shrink-0 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                                <span class="truncate"><?php echo e($driver->location ?: 'No location assigned'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="p-4 pt-0">
                    <div class="rounded-xl border border-slate-100 bg-slate-50/70 p-3">
                        <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1 mb-2">
                            <span>🚗</span> ASSIGNED VEHICLE(S)
                        </p>

                        <?php if($assignedVehicles->isNotEmpty()): ?>
                            <div class="space-y-2">
                                <?php $__currentLoopData = $assignedVehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center gap-2.5">
                                        <?php if($v->photo_url): ?>
                                            <img src="<?php echo e($v->photo_url); ?>" alt="<?php echo e($v->brand); ?> <?php echo e($v->model); ?>" class="h-9 w-12 shrink-0 rounded-md object-cover ring-1 ring-slate-200">
                                        <?php else: ?>
                                            <div class="flex h-9 w-12 shrink-0 items-center justify-center rounded-md bg-slate-200 text-slate-500">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.5 2.8C2.05 11.2 2 11.6 2 12v4c0 .6.4 1 1 1h2"/>
                                                    <circle cx="7" cy="17" r="2"/>
                                                    <path d="M9 17h6"/>
                                                    <circle cx="17" cy="17" r="2"/>
                                                </svg>
                                            </div>
                                        <?php endif; ?>
                                        <div class="min-w-0">
                                            <p class="truncate text-xs font-bold text-slate-900"><?php echo e($v->brand); ?> <?php echo e($v->model); ?></p>
                                            <span class="inline-block rounded bg-slate-200/80 px-1.5 py-0.5 text-[9px] font-extrabold tracking-wide text-slate-700">
                                                <?php echo e($v->plate_number); ?>

                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="py-2 text-center text-xs text-slate-400 font-medium">
                                No assigned vehicle
                            </div>
                        <?php endif; ?>

                        
                        <?php
                            $expDate  = $driver->license_expiration_date;
                            $daysLeft = $expDate ? now()->startOfDay()->diffInDays($expDate->startOfDay(), false) : null;
                            $licenseStatus = 'ok'; // ok | warn30 | warn7 | expired
                            if ($expDate) {
                                if ($daysLeft < 0)      $licenseStatus = 'expired';
                                elseif ($daysLeft <= 7)  $licenseStatus = 'warn7';
                                elseif ($daysLeft <= 30) $licenseStatus = 'warn30';
                            }
                        ?>
                        <div class="mt-3 rounded-lg border text-[10px] shadow-2xs overflow-hidden
                            <?php echo e($licenseStatus === 'expired' ? 'border-red-300 bg-red-50' :
                               ($licenseStatus === 'warn7'  ? 'border-red-200 bg-red-50/60' :
                               ($licenseStatus === 'warn30' ? 'border-amber-200 bg-amber-50/60' :
                               'border-slate-100 bg-white'))); ?>">
                            <div class="grid grid-cols-2 gap-2 p-2">
                                <div>
                                    <span class="block font-medium uppercase text-slate-400">LICENSE NO.</span>
                                    <span class="block font-bold text-slate-800 truncate"><?php echo e($driver->license_number ?: '—'); ?></span>
                                </div>
                                <div>
                                    <span class="block font-medium uppercase
                                        <?php echo e($licenseStatus === 'expired' ? 'text-red-500' :
                                           ($licenseStatus === 'warn7'  ? 'text-red-500' :
                                           ($licenseStatus === 'warn30' ? 'text-amber-600' :
                                           'text-slate-400'))); ?>">VALID UNTIL</span>
                                    <?php if(!$expDate): ?>
                                        <span class="block font-bold text-slate-400">—</span>
                                    <?php else: ?>
                                        <span class="block font-bold
                                            <?php echo e($licenseStatus === 'expired' ? 'text-red-700' :
                                               ($licenseStatus === 'warn7'  ? 'text-red-600' :
                                               ($licenseStatus === 'warn30' ? 'text-amber-700' :
                                               'text-slate-800'))); ?>">
                                            <?php echo e($expDate->format('M d, Y')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <?php if($licenseStatus === 'expired'): ?>
                                <div class="flex items-center gap-1.5 bg-red-600 px-2 py-1 text-white">
                                    <span class="h-1.5 w-1.5 rounded-full bg-white animate-pulse shrink-0"></span>
                                    <span class="font-bold text-[10px] uppercase tracking-wide">License Expired</span>
                                </div>
                            <?php elseif($licenseStatus === 'warn7'): ?>
                                <div class="flex items-center gap-1.5 bg-red-500 px-2 py-1 text-white">
                                    <span class="h-1.5 w-1.5 rounded-full bg-white animate-pulse shrink-0"></span>
                                    <span class="font-bold text-[10px] uppercase tracking-wide">Expires in <?php echo e($daysLeft); ?> day<?php echo e($daysLeft == 1 ? '' : 's'); ?>!</span>
                                </div>
                            <?php elseif($licenseStatus === 'warn30'): ?>
                                <div class="flex items-center gap-1.5 bg-amber-500 px-2 py-1 text-white">
                                    <span class="h-1.5 w-1.5 rounded-full bg-white animate-pulse shrink-0"></span>
                                    <span class="font-bold text-[10px] uppercase tracking-wide">Expires in <?php echo e($daysLeft); ?> days</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="mt-4 flex flex-col gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3 shadow-sm sm:flex-row sm:items-center sm:justify-between">
        <div class="flex flex-wrap items-center gap-4 text-xs text-slate-500 font-medium">
            <div>
                Showing <span class="font-bold text-slate-700"><?php echo e($drivers->firstItem() ?? 0); ?></span> to <span class="font-bold text-slate-700"><?php echo e($drivers->lastItem() ?? 0); ?></span> of <span class="font-bold text-slate-700"><?php echo e($drivers->total()); ?></span> drivers
            </div>

            <div class="flex items-center gap-2">
                <span>Rows per page:</span>
                <select id="driver-per-page-select" onchange="changeDriverPerPage(this.value)" class="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-semibold text-slate-700 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer">
                    <?php $__currentLoopData = [10, 15, 20, 25, 50, 75, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="flex items-center gap-1">
            <button type="button" onclick="goToDriverPage(1)" <?php if($drivers->onFirstPage()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &laquo;
            </button>
            <button type="button" onclick="goToDriverPage(<?php echo e(max(1, $drivers->currentPage() - 1)); ?>)" <?php if($drivers->onFirstPage()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &lt;
            </button>

            <?php $__currentLoopData = $drivers->getUrlRange(max(1, $drivers->currentPage() - 1), min($drivers->lastPage(), $drivers->currentPage() + 1)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" onclick="goToDriverPage(<?php echo e($page); ?>)" class="inline-flex h-7 w-7 items-center justify-center rounded-lg border text-xs font-bold transition <?php echo e($page == $drivers->currentPage() ? 'bg-emerald-700 text-white border-emerald-700' : 'border-slate-200 text-slate-700 hover:bg-slate-50'); ?>">
                    <?php echo e($page); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="button" onclick="goToDriverPage(<?php echo e(min($drivers->lastPage(), $drivers->currentPage() + 1)); ?>)" <?php if(!$drivers->hasMorePages()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &gt;
            </button>
            <button type="button" onclick="goToDriverPage(<?php echo e($drivers->lastPage()); ?>)" <?php if(!$drivers->hasMorePages()): echo 'disabled'; endif; ?> class="inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 text-xs text-slate-500 transition hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none">
                &raquo;
            </button>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Driver\Providers/../Views/partials/driver-results.blade.php ENDPATH**/ ?>