<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['admin', 'officer' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['admin', 'officer' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="flex items-center justify-end gap-1">
    <button
        type="button"
        onclick="openViewModal(this)"
        data-initial="<?php echo e(Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($admin->name, 0, 1))); ?>"
        data-name="<?php echo e($admin->name); ?>"
        data-email="<?php echo e($admin->email); ?>"
        data-role="<?php echo e($admin->role->label()); ?>"
        data-avatar="<?php echo e($admin->avatar_url); ?>"
        data-created="<?php echo e($admin->created_at->format('M d, Y \a\t g:i A')); ?>"
        data-updated="<?php echo e($admin->updated_at->format('M d, Y \a\t g:i A')); ?>"
        title="View"
        class="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition"
    >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/>
            <circle cx="12" cy="12" r="3"/>
        </svg>
    </button>

    <button
        type="button"
        onclick="openEditAdminModal(this)"
        data-name="<?php echo e($admin->name); ?>"
        data-email="<?php echo e($admin->email); ?>"
        data-avatar="<?php echo e($admin->avatar_url); ?>"
        data-initial="<?php echo e(Illuminate\Support\Str::upper(Illuminate\Support\Str::substr($admin->name, 0, 1))); ?>"
        data-role-value="<?php echo e($admin->role->value); ?>"
        data-phone-number="<?php echo e($admin->phone_number); ?>"
        data-location="<?php echo e($admin->location); ?>"
        data-signee1-name="<?php echo e($officer?->signee1_name); ?>"
        data-signee1-title="<?php echo e($officer?->signee1_title); ?>"
        data-signee2-name="<?php echo e($officer?->signee2_name); ?>"
        data-signee2-title="<?php echo e($officer?->signee2_title); ?>"
        data-update-url="<?php echo e(route('admin.update', $admin)); ?>"
        title="Edit"
        class="rounded-lg p-2 text-gray-500 hover:bg-emerald-50 hover:text-emerald-600 transition"
    >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5Z"/>
        </svg>
    </button>

    <button
        type="button"
        onclick="openDeleteModal(this)"
        data-name="<?php echo e($admin->name); ?>"
        data-delete-url="<?php echo e(route('admin.destroy', $admin)); ?>"
        title="Delete"
        class="rounded-lg p-2 text-gray-500 hover:bg-red-50 hover:text-red-600 transition"
    >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 6h18"/>
            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
            <path d="M10 11v6M14 11v6"/>
        </svg>
    </button>
</div>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Admin\Providers/../Views/components/row-actions.blade.php ENDPATH**/ ?>