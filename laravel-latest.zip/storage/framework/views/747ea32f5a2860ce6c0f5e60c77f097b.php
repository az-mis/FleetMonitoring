<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['vehicle']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['vehicle']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="flex items-center justify-end gap-1">
    <button
        type="button"
        onclick="openEditVehicleModal(this)"
        data-update-url="<?php echo e(route('vehicles.update', $vehicle)); ?>"
        data-plate_number="<?php echo e($vehicle->plate_number); ?>"
        data-photo="<?php echo e($vehicle->photo_url); ?>"
        data-chassis_number="<?php echo e($vehicle->chassis_number); ?>"
        data-engine_number="<?php echo e($vehicle->engine_number); ?>"
        data-brand="<?php echo e($vehicle->brand); ?>"
        data-model="<?php echo e($vehicle->model); ?>"
        data-year="<?php echo e($vehicle->year); ?>"
        data-color="<?php echo e($vehicle->color); ?>"
        data-odometer="<?php echo e($vehicle->odometer); ?>"
        data-vehicle_type="<?php echo e($vehicle->vehicle_type); ?>"
        data-fuel_type="<?php echo e($vehicle->fuel_type); ?>"
        data-location="<?php echo e($vehicle->location); ?>"
        data-created="<?php echo e($vehicle->created_at?->format('M j, Y g:i A')); ?>"
        data-updated="<?php echo e($vehicle->updated_at?->format('M j, Y g:i A')); ?>"
        data-created-by="<?php echo e($vehicle->creator ? $vehicle->creator->name . ($vehicle->creator->role ? ' (' . $vehicle->creator->role->label() . ')' : '') : ''); ?>"
        data-updated-by="<?php echo e($vehicle->updater ? $vehicle->updater->name . ($vehicle->updater->role ? ' (' . $vehicle->updater->role->label() . ')' : '') : ''); ?>"
        title="Edit"
        class="inline-flex h-7 w-7 items-center justify-center rounded-md bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white transition shadow-xs"
    >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5Z"/>
        </svg>
    </button>

    <button
        type="button"
        onclick="openDeleteVehicleModal(this)"
        data-plate_number="<?php echo e($vehicle->plate_number); ?>"
        data-delete-url="<?php echo e(route('vehicles.destroy', $vehicle)); ?>"
        title="Delete"
        class="inline-flex h-7 w-7 items-center justify-center rounded-md bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition shadow-xs"
    >
        <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 6h18"/>
            <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
            <path d="M10 11v6M14 11v6"/>
        </svg>
    </button>
</div>
<?php /**PATH C:\Users\MIS_Alvin\Herd\fleetmonitoring\Modules\Vehicle\Providers/../Views/components/row-actions.blade.php ENDPATH**/ ?>